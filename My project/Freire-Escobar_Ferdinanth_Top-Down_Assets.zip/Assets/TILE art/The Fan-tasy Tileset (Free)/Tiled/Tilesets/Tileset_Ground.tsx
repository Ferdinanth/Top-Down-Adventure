<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Tileset_Ground" tilewidth="16" tileheight="16" tilecount="1536" columns="36">
 <image source="../../Art/Tileset_Ground.png" width="576" height="672"/>
 <tile id="0"/>
 <tile id="1"/>
 <tile id="2"/>
 <tile id="3"/>
 <tile id="4"/>
 <tile id="5"/>
 <tile id="6"/>
 <tile id="7"/>
 <tile id="8"/>
 <tile id="9"/>
 <tile id="10"/>
 <tile id="11"/>
 <tile id="12"/>
 <tile id="13"/>
 <tile id="14"/>
 <tile id="15"/>
 <tile id="16"/>
 <tile id="17"/>
 <tile id="18"/>
 <tile id="19"/>
 <tile id="20"/>
 <tile id="21"/>
 <tile id="22"/>
 <tile id="23"/>
 <tile id="24"/>
 <tile id="25"/>
 <tile id="26"/>
 <tile id="27"/>
 <tile id="28"/>
 <tile id="29"/>
 <tile id="30"/>
 <tile id="31"/>
 <tile id="32"/>
 <tile id="33"/>
 <tile id="34"/>
 <tile id="35"/>
 <tile id="36"/>
 <tile id="37"/>
 <tile id="38"/>
 <tile id="39"/>
 <tile id="40"/>
 <tile id="41"/>
 <tile id="42"/>
 <tile id="43"/>
 <tile id="44"/>
 <tile id="45"/>
 <tile id="46"/>
 <tile id="47"/>
 <tile id="48"/>
 <tile id="49"/>
 <tile id="50"/>
 <tile id="51"/>
 <tile id="52"/>
 <tile id="53"/>
 <tile id="54"/>
 <tile id="55"/>
 <tile id="56"/>
 <tile id="57"/>
 <tile id="58"/>
 <tile id="59"/>
 <tile id="60"/>
 <tile id="61"/>
 <tile id="62"/>
 <tile id="63"/>
 <tile id="64"/>
 <tile id="65"/>
 <tile id="66"/>
 <tile id="67"/>
 <tile id="68"/>
 <tile id="69"/>
 <tile id="70"/>
 <tile id="71"/>
 <tile id="72"/>
 <tile id="73"/>
 <tile id="74"/>
 <tile id="75"/>
 <tile id="76"/>
 <tile id="77"/>
 <tile id="78"/>
 <tile id="79"/>
 <tile id="80"/>
 <tile id="81"/>
 <tile id="82"/>
 <tile id="83"/>
 <tile id="84"/>
 <tile id="85"/>
 <tile id="86"/>
 <tile id="87"/>
 <tile id="88"/>
 <tile id="89"/>
 <tile id="90"/>
 <tile id="91"/>
 <tile id="92"/>
 <tile id="93"/>
 <tile id="94"/>
 <tile id="95"/>
 <tile id="96"/>
 <tile id="97"/>
 <tile id="98"/>
 <tile id="99"/>
 <tile id="100"/>
 <tile id="101"/>
 <tile id="102"/>
 <tile id="103"/>
 <tile id="104"/>
 <tile id="105"/>
 <tile id="106"/>
 <tile id="107"/>
 <tile id="108"/>
 <tile id="109"/>
 <tile id="110"/>
 <tile id="111"/>
 <tile id="112"/>
 <tile id="113"/>
 <tile id="114"/>
 <tile id="115"/>
 <tile id="116"/>
 <tile id="117"/>
 <tile id="118"/>
 <tile id="119"/>
 <tile id="120"/>
 <tile id="121"/>
 <tile id="122"/>
 <tile id="123"/>
 <tile id="124"/>
 <tile id="125"/>
 <tile id="126"/>
 <tile id="127"/>
 <tile id="128"/>
 <tile id="129"/>
 <tile id="130"/>
 <tile id="131"/>
 <tile id="132"/>
 <tile id="133"/>
 <tile id="134"/>
 <tile id="135"/>
 <tile id="136"/>
 <tile id="137"/>
 <tile id="138"/>
 <tile id="139"/>
 <tile id="140"/>
 <tile id="141"/>
 <tile id="142"/>
 <tile id="143"/>
 <tile id="144"/>
 <tile id="145"/>
 <tile id="146"/>
 <tile id="147"/>
 <tile id="148"/>
 <tile id="149"/>
 <tile id="150"/>
 <tile id="151"/>
 <tile id="152"/>
 <tile id="153"/>
 <tile id="154"/>
 <tile id="155"/>
 <tile id="156"/>
 <tile id="157"/>
 <tile id="158"/>
 <tile id="159"/>
 <tile id="160"/>
 <tile id="161"/>
 <tile id="162"/>
 <tile id="163"/>
 <tile id="164"/>
 <tile id="165"/>
 <tile id="166"/>
 <tile id="167"/>
 <tile id="168"/>
 <tile id="169"/>
 <tile id="170"/>
 <tile id="171"/>
 <tile id="172"/>
 <tile id="173"/>
 <tile id="174"/>
 <tile id="175"/>
 <tile id="176"/>
 <tile id="177"/>
 <tile id="178"/>
 <tile id="179"/>
 <tile id="180"/>
 <tile id="181"/>
 <tile id="182"/>
 <tile id="183"/>
 <tile id="184"/>
 <tile id="185"/>
 <tile id="186"/>
 <tile id="187"/>
 <tile id="188"/>
 <tile id="189"/>
 <tile id="190"/>
 <tile id="191"/>
 <tile id="192"/>
 <tile id="193"/>
 <tile id="194"/>
 <tile id="195"/>
 <tile id="196"/>
 <tile id="197"/>
 <tile id="198"/>
 <tile id="199"/>
 <tile id="200"/>
 <tile id="201"/>
 <tile id="202"/>
 <tile id="203"/>
 <tile id="204"/>
 <tile id="205"/>
 <tile id="206"/>
 <tile id="207"/>
 <tile id="208"/>
 <tile id="209"/>
 <tile id="210"/>
 <tile id="211"/>
 <tile id="212"/>
 <tile id="213"/>
 <tile id="214"/>
 <tile id="215"/>
 <tile id="216"/>
 <tile id="217"/>
 <tile id="218"/>
 <tile id="219"/>
 <tile id="220"/>
 <tile id="221"/>
 <tile id="222"/>
 <tile id="223"/>
 <tile id="224"/>
 <tile id="225"/>
 <tile id="226"/>
 <tile id="227"/>
 <tile id="228"/>
 <tile id="229"/>
 <tile id="230"/>
 <tile id="231"/>
 <tile id="232"/>
 <tile id="233"/>
 <tile id="234"/>
 <tile id="235"/>
 <tile id="236"/>
 <tile id="237"/>
 <tile id="238"/>
 <tile id="239"/>
 <tile id="240"/>
 <tile id="241"/>
 <tile id="242"/>
 <tile id="243"/>
 <tile id="244"/>
 <tile id="245"/>
 <tile id="246"/>
 <tile id="247"/>
 <tile id="248"/>
 <tile id="249"/>
 <tile id="250"/>
 <tile id="251"/>
 <tile id="252"/>
 <tile id="253"/>
 <tile id="254"/>
 <tile id="255"/>
 <tile id="256"/>
 <tile id="257"/>
 <tile id="258"/>
 <tile id="259"/>
 <tile id="260"/>
 <tile id="261"/>
 <tile id="262"/>
 <tile id="263"/>
 <tile id="264"/>
 <tile id="265"/>
 <tile id="266"/>
 <tile id="267"/>
 <tile id="268"/>
 <tile id="269"/>
 <tile id="270"/>
 <tile id="271"/>
 <tile id="272"/>
 <tile id="273"/>
 <tile id="274"/>
 <tile id="275"/>
 <tile id="276"/>
 <tile id="277"/>
 <tile id="278"/>
 <tile id="279"/>
 <tile id="280"/>
 <tile id="281"/>
 <tile id="282"/>
 <tile id="283"/>
 <tile id="284"/>
 <tile id="285"/>
 <tile id="286"/>
 <tile id="287"/>
 <tile id="288" probability="0.3"/>
 <tile id="289" probability="0.3"/>
 <tile id="290" probability="0.3"/>
 <tile id="291" probability="0.3"/>
 <tile id="292" probability="0.3"/>
 <tile id="293" probability="0.3"/>
 <tile id="294"/>
 <tile id="295"/>
 <tile id="296"/>
 <tile id="297"/>
 <tile id="298"/>
 <tile id="299"/>
 <tile id="300"/>
 <tile id="301"/>
 <tile id="302"/>
 <tile id="303"/>
 <tile id="304"/>
 <tile id="305"/>
 <tile id="306"/>
 <tile id="307"/>
 <tile id="308"/>
 <tile id="309"/>
 <tile id="310"/>
 <tile id="311"/>
 <tile id="312"/>
 <tile id="313"/>
 <tile id="314"/>
 <tile id="315"/>
 <tile id="316"/>
 <tile id="317"/>
 <tile id="318"/>
 <tile id="319"/>
 <tile id="320"/>
 <tile id="321"/>
 <tile id="322"/>
 <tile id="323"/>
 <tile id="324" probability="0.3"/>
 <tile id="325" probability="0.3"/>
 <tile id="326" probability="0.3"/>
 <tile id="327" probability="0.3"/>
 <tile id="328" probability="0.3"/>
 <tile id="329" probability="0.3"/>
 <tile id="330"/>
 <tile id="331"/>
 <tile id="332"/>
 <tile id="333"/>
 <tile id="334"/>
 <tile id="335"/>
 <tile id="336"/>
 <tile id="337"/>
 <tile id="338"/>
 <tile id="339"/>
 <tile id="340"/>
 <tile id="341"/>
 <tile id="342"/>
 <tile id="343"/>
 <tile id="344"/>
 <tile id="345"/>
 <tile id="346"/>
 <tile id="347"/>
 <tile id="348"/>
 <tile id="349"/>
 <tile id="350"/>
 <tile id="351"/>
 <tile id="352"/>
 <tile id="353"/>
 <tile id="354"/>
 <tile id="355"/>
 <tile id="356"/>
 <tile id="357"/>
 <tile id="358"/>
 <tile id="359"/>
 <tile id="360"/>
 <tile id="361"/>
 <tile id="362"/>
 <tile id="363"/>
 <tile id="364"/>
 <tile id="365"/>
 <tile id="366"/>
 <tile id="367"/>
 <tile id="368"/>
 <tile id="369"/>
 <tile id="370"/>
 <tile id="371"/>
 <tile id="372"/>
 <tile id="373"/>
 <tile id="374"/>
 <tile id="375"/>
 <tile id="376"/>
 <tile id="377"/>
 <tile id="378"/>
 <tile id="379"/>
 <tile id="380"/>
 <tile id="381"/>
 <tile id="382"/>
 <tile id="383"/>
 <tile id="384"/>
 <tile id="385"/>
 <tile id="386"/>
 <tile id="387"/>
 <tile id="388"/>
 <tile id="389"/>
 <tile id="390"/>
 <tile id="391"/>
 <tile id="392"/>
 <tile id="393"/>
 <tile id="394"/>
 <tile id="395"/>
 <tile id="396"/>
 <tile id="397"/>
 <tile id="398"/>
 <tile id="399"/>
 <tile id="400"/>
 <tile id="401"/>
 <tile id="402"/>
 <tile id="403"/>
 <tile id="404"/>
 <tile id="405"/>
 <tile id="406"/>
 <tile id="407"/>
 <tile id="408"/>
 <tile id="409"/>
 <tile id="410"/>
 <tile id="411"/>
 <tile id="412"/>
 <tile id="413"/>
 <tile id="414"/>
 <tile id="415"/>
 <tile id="416"/>
 <tile id="417"/>
 <tile id="418"/>
 <tile id="419"/>
 <tile id="420"/>
 <tile id="421"/>
 <tile id="422"/>
 <tile id="423"/>
 <tile id="424"/>
 <tile id="425"/>
 <tile id="426"/>
 <tile id="427"/>
 <tile id="428"/>
 <tile id="429"/>
 <tile id="430"/>
 <tile id="431"/>
 <tile id="432"/>
 <tile id="433"/>
 <tile id="434"/>
 <tile id="435"/>
 <tile id="436"/>
 <tile id="437"/>
 <tile id="438"/>
 <tile id="439"/>
 <tile id="440"/>
 <tile id="441"/>
 <tile id="442"/>
 <tile id="443"/>
 <tile id="444"/>
 <tile id="445"/>
 <tile id="446"/>
 <tile id="447"/>
 <tile id="448"/>
 <tile id="449"/>
 <tile id="450"/>
 <tile id="451"/>
 <tile id="452"/>
 <tile id="453"/>
 <tile id="454"/>
 <tile id="455"/>
 <tile id="456"/>
 <tile id="457"/>
 <tile id="458"/>
 <tile id="459"/>
 <tile id="460"/>
 <tile id="461"/>
 <tile id="462"/>
 <tile id="463"/>
 <tile id="464"/>
 <tile id="465"/>
 <tile id="466"/>
 <tile id="467"/>
 <tile id="468"/>
 <tile id="469"/>
 <tile id="470"/>
 <tile id="471"/>
 <tile id="472"/>
 <tile id="473"/>
 <tile id="474"/>
 <tile id="475"/>
 <tile id="476"/>
 <tile id="477"/>
 <tile id="478"/>
 <tile id="479"/>
 <tile id="480"/>
 <tile id="481"/>
 <tile id="482"/>
 <tile id="483"/>
 <tile id="484"/>
 <tile id="485"/>
 <tile id="486"/>
 <tile id="487"/>
 <tile id="488"/>
 <tile id="489"/>
 <tile id="490"/>
 <tile id="491"/>
 <tile id="492"/>
 <tile id="493"/>
 <tile id="494"/>
 <tile id="495"/>
 <tile id="496"/>
 <tile id="497"/>
 <tile id="498"/>
 <tile id="499"/>
 <tile id="500"/>
 <tile id="501"/>
 <tile id="502"/>
 <tile id="503"/>
 <tile id="504"/>
 <tile id="505"/>
 <tile id="506"/>
 <tile id="507"/>
 <tile id="508"/>
 <tile id="509"/>
 <tile id="510"/>
 <tile id="511"/>
 <tile id="512"/>
 <tile id="513"/>
 <tile id="514"/>
 <tile id="515"/>
 <tile id="516"/>
 <tile id="517"/>
 <tile id="518"/>
 <tile id="519"/>
 <tile id="520"/>
 <tile id="521"/>
 <tile id="522"/>
 <tile id="523"/>
 <tile id="524"/>
 <tile id="525"/>
 <tile id="526"/>
 <tile id="527"/>
 <tile id="528"/>
 <tile id="529"/>
 <tile id="530"/>
 <tile id="531"/>
 <tile id="532"/>
 <tile id="533"/>
 <tile id="534"/>
 <tile id="535"/>
 <tile id="536"/>
 <tile id="537"/>
 <tile id="538"/>
 <tile id="539"/>
 <tile id="540"/>
 <tile id="541"/>
 <tile id="542"/>
 <tile id="543"/>
 <tile id="544"/>
 <tile id="545"/>
 <tile id="546"/>
 <tile id="547"/>
 <tile id="548"/>
 <tile id="549"/>
 <tile id="550"/>
 <tile id="551"/>
 <tile id="552"/>
 <tile id="553"/>
 <tile id="554"/>
 <tile id="555"/>
 <tile id="556"/>
 <tile id="557"/>
 <tile id="558"/>
 <tile id="559"/>
 <tile id="560"/>
 <tile id="561"/>
 <tile id="562"/>
 <tile id="563"/>
 <tile id="564"/>
 <tile id="565"/>
 <tile id="566"/>
 <tile id="567"/>
 <tile id="568"/>
 <tile id="569"/>
 <tile id="570"/>
 <tile id="571"/>
 <tile id="572"/>
 <tile id="573"/>
 <tile id="574"/>
 <tile id="575"/>
 <tile id="576"/>
 <tile id="577"/>
 <tile id="578"/>
 <tile id="579"/>
 <tile id="580"/>
 <tile id="581"/>
 <tile id="582"/>
 <tile id="583"/>
 <tile id="584"/>
 <tile id="585"/>
 <tile id="586"/>
 <tile id="587"/>
 <tile id="588"/>
 <tile id="589"/>
 <tile id="590"/>
 <tile id="591"/>
 <tile id="592"/>
 <tile id="593"/>
 <tile id="594"/>
 <tile id="595"/>
 <tile id="596"/>
 <tile id="597"/>
 <tile id="598"/>
 <tile id="599"/>
 <tile id="600"/>
 <tile id="601"/>
 <tile id="602"/>
 <tile id="603"/>
 <tile id="604"/>
 <tile id="605"/>
 <tile id="606"/>
 <tile id="607"/>
 <tile id="608"/>
 <tile id="609"/>
 <tile id="610"/>
 <tile id="611"/>
 <tile id="612"/>
 <tile id="613"/>
 <tile id="614"/>
 <tile id="615"/>
 <tile id="616"/>
 <tile id="617"/>
 <tile id="618"/>
 <tile id="619"/>
 <tile id="620"/>
 <tile id="621"/>
 <tile id="622"/>
 <tile id="623"/>
 <tile id="624"/>
 <tile id="625"/>
 <tile id="626"/>
 <tile id="627"/>
 <tile id="628"/>
 <tile id="629"/>
 <tile id="630"/>
 <tile id="631"/>
 <tile id="632"/>
 <tile id="633"/>
 <tile id="634"/>
 <tile id="635"/>
 <tile id="636"/>
 <tile id="637"/>
 <tile id="638"/>
 <tile id="639"/>
 <tile id="640"/>
 <tile id="641"/>
 <tile id="642"/>
 <tile id="643"/>
 <tile id="644"/>
 <tile id="645"/>
 <tile id="646"/>
 <tile id="647"/>
 <tile id="648"/>
 <tile id="649"/>
 <tile id="650"/>
 <tile id="651"/>
 <tile id="652"/>
 <tile id="653"/>
 <tile id="654"/>
 <tile id="655"/>
 <tile id="656"/>
 <tile id="657"/>
 <tile id="658"/>
 <tile id="659"/>
 <tile id="660"/>
 <tile id="661"/>
 <tile id="662"/>
 <tile id="663"/>
 <tile id="664"/>
 <tile id="665"/>
 <tile id="666"/>
 <tile id="667"/>
 <tile id="668"/>
 <tile id="669"/>
 <tile id="670"/>
 <tile id="671"/>
 <tile id="672"/>
 <tile id="673"/>
 <tile id="674"/>
 <tile id="675"/>
 <tile id="676"/>
 <tile id="677"/>
 <tile id="678"/>
 <tile id="679"/>
 <tile id="680"/>
 <tile id="681"/>
 <tile id="682"/>
 <tile id="683"/>
 <tile id="684"/>
 <tile id="685"/>
 <tile id="686"/>
 <tile id="687"/>
 <tile id="688"/>
 <tile id="689"/>
 <tile id="690"/>
 <tile id="691"/>
 <tile id="692"/>
 <tile id="693"/>
 <tile id="694"/>
 <tile id="695"/>
 <tile id="696"/>
 <tile id="697"/>
 <tile id="698"/>
 <tile id="699"/>
 <tile id="700"/>
 <tile id="701"/>
 <tile id="702"/>
 <tile id="703"/>
 <tile id="704"/>
 <tile id="705"/>
 <tile id="706"/>
 <tile id="707"/>
 <tile id="708"/>
 <tile id="709"/>
 <tile id="710"/>
 <tile id="711"/>
 <tile id="712"/>
 <tile id="713"/>
 <tile id="714"/>
 <tile id="715"/>
 <tile id="716"/>
 <tile id="717"/>
 <tile id="718"/>
 <tile id="719"/>
 <tile id="720"/>
 <tile id="721"/>
 <tile id="722"/>
 <tile id="723"/>
 <tile id="724"/>
 <tile id="725"/>
 <tile id="726"/>
 <tile id="727"/>
 <tile id="728"/>
 <tile id="729"/>
 <tile id="730"/>
 <tile id="731"/>
 <tile id="732"/>
 <tile id="733"/>
 <tile id="734"/>
 <tile id="735"/>
 <tile id="736"/>
 <tile id="737"/>
 <tile id="738"/>
 <tile id="739"/>
 <tile id="740"/>
 <tile id="741"/>
 <tile id="742"/>
 <tile id="743"/>
 <tile id="744"/>
 <tile id="745"/>
 <tile id="746"/>
 <tile id="747"/>
 <tile id="748"/>
 <tile id="749"/>
 <tile id="750"/>
 <tile id="751"/>
 <tile id="752"/>
 <tile id="753"/>
 <tile id="754"/>
 <tile id="755"/>
 <tile id="756"/>
 <tile id="757"/>
 <tile id="758"/>
 <tile id="759"/>
 <tile id="760"/>
 <tile id="761"/>
 <tile id="762"/>
 <tile id="763"/>
 <tile id="764"/>
 <tile id="765"/>
 <tile id="766"/>
 <tile id="767"/>
 <tile id="768"/>
 <tile id="769"/>
 <tile id="770"/>
 <tile id="771"/>
 <tile id="772"/>
 <tile id="773"/>
 <tile id="774"/>
 <tile id="775"/>
 <tile id="776"/>
 <tile id="777"/>
 <tile id="778"/>
 <tile id="779"/>
 <tile id="780"/>
 <tile id="781"/>
 <tile id="782"/>
 <tile id="783"/>
 <tile id="784"/>
 <tile id="785"/>
 <tile id="786"/>
 <tile id="787"/>
 <tile id="788"/>
 <tile id="789"/>
 <tile id="790"/>
 <tile id="791"/>
 <tile id="792" probability="0.3"/>
 <tile id="793" probability="0.3"/>
 <tile id="794" probability="0.3"/>
 <tile id="795" probability="0.3"/>
 <tile id="796" probability="0.3"/>
 <tile id="797" probability="0.3"/>
 <tile id="798"/>
 <tile id="799"/>
 <tile id="800"/>
 <tile id="801"/>
 <tile id="802"/>
 <tile id="803"/>
 <tile id="804"/>
 <tile id="805"/>
 <tile id="806"/>
 <tile id="807"/>
 <tile id="808"/>
 <tile id="809"/>
 <tile id="810"/>
 <tile id="811"/>
 <tile id="812"/>
 <tile id="813"/>
 <tile id="814"/>
 <tile id="815"/>
 <tile id="816"/>
 <tile id="817"/>
 <tile id="818"/>
 <tile id="819"/>
 <tile id="820"/>
 <tile id="821"/>
 <tile id="822"/>
 <tile id="823"/>
 <tile id="824"/>
 <tile id="825"/>
 <tile id="826"/>
 <tile id="827"/>
 <tile id="828" probability="0.3"/>
 <tile id="829" probability="0.3"/>
 <tile id="830" probability="0.3"/>
 <tile id="831" probability="0.3"/>
 <tile id="832" probability="0.3"/>
 <tile id="833" probability="0.3"/>
 <tile id="834"/>
 <tile id="835"/>
 <tile id="836"/>
 <tile id="837"/>
 <tile id="838"/>
 <tile id="839"/>
 <tile id="840"/>
 <tile id="841"/>
 <tile id="842"/>
 <tile id="843"/>
 <tile id="844"/>
 <tile id="845"/>
 <tile id="846"/>
 <tile id="847"/>
 <tile id="848"/>
 <tile id="849"/>
 <tile id="850"/>
 <tile id="851"/>
 <tile id="852"/>
 <tile id="853"/>
 <tile id="854"/>
 <tile id="855"/>
 <tile id="856"/>
 <tile id="857"/>
 <tile id="858"/>
 <tile id="859"/>
 <tile id="860"/>
 <tile id="861"/>
 <tile id="862"/>
 <tile id="863"/>
 <tile id="864"/>
 <tile id="865"/>
 <tile id="866"/>
 <tile id="867"/>
 <tile id="868"/>
 <tile id="869"/>
 <tile id="870"/>
 <tile id="871"/>
 <tile id="872"/>
 <tile id="873"/>
 <tile id="874"/>
 <tile id="875"/>
 <tile id="876"/>
 <tile id="877"/>
 <tile id="878"/>
 <tile id="879"/>
 <tile id="880"/>
 <tile id="881"/>
 <tile id="882"/>
 <tile id="883"/>
 <tile id="884"/>
 <tile id="885"/>
 <tile id="886"/>
 <tile id="887"/>
 <tile id="888"/>
 <tile id="889"/>
 <tile id="890"/>
 <tile id="891"/>
 <tile id="892"/>
 <tile id="893"/>
 <tile id="894"/>
 <tile id="895"/>
 <tile id="896"/>
 <tile id="897"/>
 <tile id="898"/>
 <tile id="899"/>
 <tile id="900"/>
 <tile id="901"/>
 <tile id="902"/>
 <tile id="903"/>
 <tile id="904"/>
 <tile id="905"/>
 <tile id="906"/>
 <tile id="907"/>
 <tile id="908"/>
 <tile id="909"/>
 <tile id="910"/>
 <tile id="911"/>
 <tile id="912"/>
 <tile id="913"/>
 <tile id="914"/>
 <tile id="915"/>
 <tile id="916"/>
 <tile id="917"/>
 <tile id="918"/>
 <tile id="919"/>
 <tile id="920"/>
 <tile id="921"/>
 <tile id="922"/>
 <tile id="923"/>
 <tile id="924"/>
 <tile id="925"/>
 <tile id="926"/>
 <tile id="927"/>
 <tile id="928"/>
 <tile id="929"/>
 <tile id="930"/>
 <tile id="931"/>
 <tile id="932"/>
 <tile id="933"/>
 <tile id="934"/>
 <tile id="935"/>
 <tile id="936"/>
 <tile id="937"/>
 <tile id="938"/>
 <tile id="939"/>
 <tile id="940"/>
 <tile id="941"/>
 <tile id="942"/>
 <tile id="943"/>
 <tile id="944"/>
 <tile id="945"/>
 <tile id="946"/>
 <tile id="947"/>
 <tile id="948"/>
 <tile id="949"/>
 <tile id="950"/>
 <tile id="951"/>
 <tile id="952"/>
 <tile id="953"/>
 <tile id="954"/>
 <tile id="955"/>
 <tile id="956"/>
 <tile id="957"/>
 <tile id="958"/>
 <tile id="959"/>
 <tile id="960"/>
 <tile id="961"/>
 <tile id="962"/>
 <tile id="963"/>
 <tile id="964"/>
 <tile id="965"/>
 <tile id="966"/>
 <tile id="967"/>
 <tile id="968"/>
 <tile id="969"/>
 <tile id="970"/>
 <tile id="971"/>
 <tile id="972"/>
 <tile id="973"/>
 <tile id="974"/>
 <tile id="975"/>
 <tile id="976"/>
 <tile id="977"/>
 <tile id="978"/>
 <tile id="979"/>
 <tile id="980"/>
 <tile id="981"/>
 <tile id="982"/>
 <tile id="983"/>
 <tile id="984"/>
 <tile id="985"/>
 <tile id="986"/>
 <tile id="987"/>
 <tile id="988"/>
 <tile id="989"/>
 <tile id="990"/>
 <tile id="991"/>
 <tile id="992"/>
 <tile id="993"/>
 <tile id="994"/>
 <tile id="995"/>
 <tile id="996"/>
 <tile id="997"/>
 <tile id="998"/>
 <tile id="999"/>
 <tile id="1000"/>
 <tile id="1001"/>
 <tile id="1002"/>
 <tile id="1003"/>
 <tile id="1004"/>
 <tile id="1005"/>
 <tile id="1006"/>
 <tile id="1007"/>
 <tile id="1008"/>
 <tile id="1009"/>
 <tile id="1010"/>
 <tile id="1011"/>
 <tile id="1012"/>
 <tile id="1013"/>
 <tile id="1014"/>
 <tile id="1015"/>
 <tile id="1016"/>
 <tile id="1017"/>
 <tile id="1018"/>
 <tile id="1019"/>
 <tile id="1020"/>
 <tile id="1021"/>
 <tile id="1022"/>
 <tile id="1023"/>
 <tile id="1024"/>
 <tile id="1025"/>
 <tile id="1026"/>
 <tile id="1027"/>
 <tile id="1028"/>
 <tile id="1029"/>
 <tile id="1030"/>
 <tile id="1031"/>
 <tile id="1032"/>
 <tile id="1033"/>
 <tile id="1034"/>
 <tile id="1035"/>
 <tile id="1036"/>
 <tile id="1037"/>
 <tile id="1038"/>
 <tile id="1039"/>
 <tile id="1040"/>
 <tile id="1041"/>
 <tile id="1042"/>
 <tile id="1043"/>
 <tile id="1044"/>
 <tile id="1045"/>
 <tile id="1046"/>
 <tile id="1047"/>
 <tile id="1048"/>
 <tile id="1049"/>
 <tile id="1050"/>
 <tile id="1051"/>
 <tile id="1052"/>
 <tile id="1053"/>
 <tile id="1054"/>
 <tile id="1055"/>
 <tile id="1056"/>
 <tile id="1057"/>
 <tile id="1058"/>
 <tile id="1059"/>
 <tile id="1060"/>
 <tile id="1061"/>
 <tile id="1062"/>
 <tile id="1063"/>
 <tile id="1064"/>
 <tile id="1065"/>
 <tile id="1066"/>
 <tile id="1067"/>
 <tile id="1068"/>
 <tile id="1069"/>
 <tile id="1070"/>
 <tile id="1071"/>
 <tile id="1072"/>
 <tile id="1073"/>
 <tile id="1074"/>
 <tile id="1075"/>
 <tile id="1076"/>
 <tile id="1077"/>
 <tile id="1078"/>
 <tile id="1079"/>
 <tile id="1080"/>
 <tile id="1081"/>
 <tile id="1082"/>
 <tile id="1083"/>
 <tile id="1084"/>
 <tile id="1085"/>
 <tile id="1086"/>
 <tile id="1087"/>
 <tile id="1088"/>
 <tile id="1089"/>
 <tile id="1090"/>
 <tile id="1091"/>
 <tile id="1092"/>
 <tile id="1093"/>
 <tile id="1094"/>
 <tile id="1095"/>
 <tile id="1096"/>
 <tile id="1097"/>
 <tile id="1098"/>
 <tile id="1099"/>
 <tile id="1100"/>
 <tile id="1101"/>
 <tile id="1102"/>
 <tile id="1103"/>
 <tile id="1104"/>
 <tile id="1105"/>
 <tile id="1106"/>
 <tile id="1107"/>
 <tile id="1108"/>
 <tile id="1109"/>
 <tile id="1110"/>
 <tile id="1111"/>
 <tile id="1112"/>
 <tile id="1113"/>
 <tile id="1114"/>
 <tile id="1115"/>
 <tile id="1116"/>
 <tile id="1117"/>
 <tile id="1118"/>
 <tile id="1119"/>
 <tile id="1120"/>
 <tile id="1121"/>
 <tile id="1122"/>
 <tile id="1123"/>
 <tile id="1124"/>
 <tile id="1125"/>
 <tile id="1126"/>
 <tile id="1127"/>
 <tile id="1128"/>
 <tile id="1129"/>
 <tile id="1130"/>
 <tile id="1131"/>
 <tile id="1132"/>
 <tile id="1133"/>
 <tile id="1134"/>
 <tile id="1135"/>
 <tile id="1136"/>
 <tile id="1137"/>
 <tile id="1138"/>
 <tile id="1139"/>
 <tile id="1140"/>
 <tile id="1141"/>
 <tile id="1142"/>
 <tile id="1143"/>
 <tile id="1144"/>
 <tile id="1145"/>
 <tile id="1146"/>
 <tile id="1147"/>
 <tile id="1148"/>
 <tile id="1149"/>
 <tile id="1150"/>
 <tile id="1151"/>
 <tile id="1152"/>
 <tile id="1153"/>
 <tile id="1154"/>
 <tile id="1155"/>
 <tile id="1156"/>
 <tile id="1157"/>
 <tile id="1158"/>
 <tile id="1159"/>
 <tile id="1160"/>
 <tile id="1161"/>
 <tile id="1162"/>
 <tile id="1163"/>
 <tile id="1164"/>
 <tile id="1165"/>
 <tile id="1166"/>
 <tile id="1167"/>
 <tile id="1168"/>
 <tile id="1169"/>
 <tile id="1170"/>
 <tile id="1171"/>
 <tile id="1172"/>
 <tile id="1173"/>
 <tile id="1174"/>
 <tile id="1175"/>
 <tile id="1176"/>
 <tile id="1177"/>
 <tile id="1178"/>
 <tile id="1179"/>
 <tile id="1180"/>
 <tile id="1181"/>
 <tile id="1182"/>
 <tile id="1183"/>
 <tile id="1184"/>
 <tile id="1185"/>
 <tile id="1186"/>
 <tile id="1187"/>
 <tile id="1188"/>
 <tile id="1189"/>
 <tile id="1190"/>
 <tile id="1191"/>
 <tile id="1192"/>
 <tile id="1193"/>
 <tile id="1194"/>
 <tile id="1195"/>
 <tile id="1196"/>
 <tile id="1197"/>
 <tile id="1198"/>
 <tile id="1199"/>
 <tile id="1200"/>
 <tile id="1201"/>
 <tile id="1202"/>
 <tile id="1203"/>
 <tile id="1204"/>
 <tile id="1205"/>
 <tile id="1206"/>
 <tile id="1207"/>
 <tile id="1208"/>
 <tile id="1209"/>
 <tile id="1210"/>
 <tile id="1211"/>
 <tile id="1212"/>
 <tile id="1213"/>
 <tile id="1214"/>
 <tile id="1215"/>
 <tile id="1216"/>
 <tile id="1217"/>
 <tile id="1218"/>
 <tile id="1219"/>
 <tile id="1220"/>
 <tile id="1221"/>
 <tile id="1222"/>
 <tile id="1223"/>
 <tile id="1224"/>
 <tile id="1225"/>
 <tile id="1226"/>
 <tile id="1227"/>
 <tile id="1228"/>
 <tile id="1229"/>
 <tile id="1230"/>
 <tile id="1231"/>
 <tile id="1232"/>
 <tile id="1233"/>
 <tile id="1234"/>
 <tile id="1235"/>
 <tile id="1236"/>
 <tile id="1237"/>
 <tile id="1238"/>
 <tile id="1239"/>
 <tile id="1240"/>
 <tile id="1241"/>
 <tile id="1242"/>
 <tile id="1243"/>
 <tile id="1244"/>
 <tile id="1245"/>
 <tile id="1246"/>
 <tile id="1247"/>
 <tile id="1248"/>
 <tile id="1249"/>
 <tile id="1250"/>
 <tile id="1251"/>
 <tile id="1252"/>
 <tile id="1253"/>
 <tile id="1254"/>
 <tile id="1255"/>
 <tile id="1256"/>
 <tile id="1257"/>
 <tile id="1258"/>
 <tile id="1259"/>
 <tile id="1260"/>
 <tile id="1261"/>
 <tile id="1262"/>
 <tile id="1263"/>
 <tile id="1264"/>
 <tile id="1265"/>
 <tile id="1266"/>
 <tile id="1267"/>
 <tile id="1268"/>
 <tile id="1269"/>
 <tile id="1270"/>
 <tile id="1271"/>
 <tile id="1272"/>
 <tile id="1273"/>
 <tile id="1274"/>
 <tile id="1275"/>
 <tile id="1276"/>
 <tile id="1277"/>
 <tile id="1278"/>
 <tile id="1279"/>
 <tile id="1280"/>
 <tile id="1281"/>
 <tile id="1282"/>
 <tile id="1283"/>
 <tile id="1284"/>
 <tile id="1285"/>
 <tile id="1286"/>
 <tile id="1287"/>
 <tile id="1288"/>
 <tile id="1289"/>
 <tile id="1290"/>
 <tile id="1291"/>
 <tile id="1292"/>
 <tile id="1293"/>
 <tile id="1294"/>
 <tile id="1295"/>
 <tile id="1296" probability="0.3"/>
 <tile id="1297" probability="0.3"/>
 <tile id="1298" probability="0.3"/>
 <tile id="1299" probability="0.3"/>
 <tile id="1300" probability="0.3"/>
 <tile id="1301" probability="0.3"/>
 <tile id="1302"/>
 <tile id="1303"/>
 <tile id="1304"/>
 <tile id="1305"/>
 <tile id="1306"/>
 <tile id="1307"/>
 <tile id="1308"/>
 <tile id="1309"/>
 <tile id="1310"/>
 <tile id="1311"/>
 <tile id="1312"/>
 <tile id="1313"/>
 <tile id="1314"/>
 <tile id="1315"/>
 <tile id="1316"/>
 <tile id="1317"/>
 <tile id="1318"/>
 <tile id="1319"/>
 <tile id="1320"/>
 <tile id="1321"/>
 <tile id="1322"/>
 <tile id="1323"/>
 <tile id="1324"/>
 <tile id="1325"/>
 <tile id="1326"/>
 <tile id="1327"/>
 <tile id="1328"/>
 <tile id="1329"/>
 <tile id="1330"/>
 <tile id="1331"/>
 <tile id="1332" probability="0.3"/>
 <tile id="1333" probability="0.3"/>
 <tile id="1334" probability="0.3"/>
 <tile id="1335" probability="0.3"/>
 <tile id="1336" probability="0.3"/>
 <tile id="1337" probability="0.3"/>
 <tile id="1338"/>
 <tile id="1339"/>
 <tile id="1340"/>
 <tile id="1341"/>
 <tile id="1342"/>
 <tile id="1343"/>
 <tile id="1344"/>
 <tile id="1345"/>
 <tile id="1346"/>
 <tile id="1347"/>
 <tile id="1348"/>
 <tile id="1349"/>
 <tile id="1350"/>
 <tile id="1351"/>
 <tile id="1352"/>
 <tile id="1353"/>
 <tile id="1354"/>
 <tile id="1355"/>
 <tile id="1356"/>
 <tile id="1357"/>
 <tile id="1358"/>
 <tile id="1359"/>
 <tile id="1360"/>
 <tile id="1361"/>
 <tile id="1362"/>
 <tile id="1363"/>
 <tile id="1364"/>
 <tile id="1365"/>
 <tile id="1366"/>
 <tile id="1367"/>
 <tile id="1368"/>
 <tile id="1369"/>
 <tile id="1370"/>
 <tile id="1371"/>
 <tile id="1372"/>
 <tile id="1373"/>
 <tile id="1374"/>
 <tile id="1375"/>
 <tile id="1376"/>
 <tile id="1377"/>
 <tile id="1378"/>
 <tile id="1379"/>
 <tile id="1380"/>
 <tile id="1381"/>
 <tile id="1382"/>
 <tile id="1383"/>
 <tile id="1384"/>
 <tile id="1385"/>
 <tile id="1386"/>
 <tile id="1387"/>
 <tile id="1388"/>
 <tile id="1389"/>
 <tile id="1390"/>
 <tile id="1391"/>
 <tile id="1392"/>
 <tile id="1393"/>
 <tile id="1394"/>
 <tile id="1395"/>
 <tile id="1396"/>
 <tile id="1397"/>
 <tile id="1398"/>
 <tile id="1399"/>
 <tile id="1400"/>
 <tile id="1401"/>
 <tile id="1402"/>
 <tile id="1403"/>
 <tile id="1404"/>
 <tile id="1405"/>
 <tile id="1406"/>
 <tile id="1407"/>
 <tile id="1408"/>
 <tile id="1409"/>
 <tile id="1410"/>
 <tile id="1411"/>
 <tile id="1412"/>
 <tile id="1413"/>
 <tile id="1414"/>
 <tile id="1415"/>
 <tile id="1416"/>
 <tile id="1417"/>
 <tile id="1418"/>
 <tile id="1419"/>
 <tile id="1420"/>
 <tile id="1421"/>
 <tile id="1422"/>
 <tile id="1423"/>
 <tile id="1424"/>
 <tile id="1425"/>
 <tile id="1426"/>
 <tile id="1427"/>
 <tile id="1428"/>
 <tile id="1429"/>
 <tile id="1430"/>
 <tile id="1431"/>
 <tile id="1432"/>
 <tile id="1433"/>
 <tile id="1434"/>
 <tile id="1435"/>
 <tile id="1436"/>
 <tile id="1437"/>
 <tile id="1438"/>
 <tile id="1439"/>
 <tile id="1440"/>
 <tile id="1441"/>
 <tile id="1442"/>
 <tile id="1443"/>
 <tile id="1444"/>
 <tile id="1445"/>
 <tile id="1446"/>
 <tile id="1447"/>
 <tile id="1448"/>
 <tile id="1449"/>
 <tile id="1450"/>
 <tile id="1451"/>
 <tile id="1452"/>
 <tile id="1453"/>
 <tile id="1454"/>
 <tile id="1455"/>
 <tile id="1456"/>
 <tile id="1457"/>
 <tile id="1458"/>
 <tile id="1459"/>
 <tile id="1460"/>
 <tile id="1461"/>
 <tile id="1462"/>
 <tile id="1463"/>
 <tile id="1464"/>
 <tile id="1465"/>
 <tile id="1466"/>
 <tile id="1467"/>
 <tile id="1468"/>
 <tile id="1469"/>
 <tile id="1470"/>
 <tile id="1471"/>
 <tile id="1472"/>
 <tile id="1473"/>
 <tile id="1474"/>
 <tile id="1475"/>
 <tile id="1476"/>
 <tile id="1477"/>
 <tile id="1478"/>
 <tile id="1479"/>
 <tile id="1480"/>
 <tile id="1481"/>
 <tile id="1482"/>
 <tile id="1483"/>
 <tile id="1484"/>
 <tile id="1485"/>
 <tile id="1486"/>
 <tile id="1487"/>
 <tile id="1488"/>
 <tile id="1489"/>
 <tile id="1490"/>
 <tile id="1491"/>
 <tile id="1492"/>
 <tile id="1493"/>
 <tile id="1494"/>
 <tile id="1495"/>
 <tile id="1496"/>
 <tile id="1497"/>
 <tile id="1498"/>
 <tile id="1499"/>
 <tile id="1500"/>
 <tile id="1501"/>
 <tile id="1502"/>
 <tile id="1503"/>
 <tile id="1504"/>
 <tile id="1505"/>
 <tile id="1506"/>
 <tile id="1507"/>
 <tile id="1508"/>
 <tile id="1509"/>
 <tile id="1510"/>
 <tile id="1511"/>
 <tile id="1800" probability="0.3"/>
 <tile id="1801" probability="0.3"/>
 <tile id="1802" probability="0.3"/>
 <tile id="1803" probability="0.3"/>
 <tile id="1804" probability="0.3"/>
 <tile id="1805" probability="0.3"/>
 <tile id="1836" probability="0.3"/>
 <tile id="1837" probability="0.3"/>
 <tile id="1838" probability="0.3"/>
 <tile id="1839" probability="0.3"/>
 <tile id="1840" probability="0.3"/>
 <tile id="1841" probability="0.3"/>
 <tile id="2304" probability="0.3"/>
 <tile id="2305" probability="0.3"/>
 <tile id="2306" probability="0.3"/>
 <tile id="2307" probability="0.3"/>
 <tile id="2308" probability="0.3"/>
 <tile id="2309" probability="0.3"/>
 <tile id="2340" probability="0.3"/>
 <tile id="2341" probability="0.3"/>
 <tile id="2342" probability="0.3"/>
 <tile id="2343" probability="0.3"/>
 <tile id="2344" probability="0.3"/>
 <tile id="2345" probability="0.3"/>
 <wangsets>
  <wangset name="Grounds" type="mixed" tile="-1">
   <wangcolor name="Empty" color="#ff0000" tile="-1" probability="1"/>
   <wangcolor name="Grass" color="#5500ff" tile="-1" probability="1"/>
   <wangcolor name="Light Grass" color="#ffaa00" tile="-1" probability="1"/>
   <wangcolor name="Dark Grass" color="#ff00ff" tile="-1" probability="1"/>
   <wangcolor name="Dirt" color="#ffff7f" tile="-1" probability="1"/>
   <wangtile tileid="0" wangid="1,1,1,1,2,1,1,1"/>
   <wangtile tileid="1" wangid="1,1,2,2,2,1,1,1"/>
   <wangtile tileid="2" wangid="1,1,2,2,2,2,2,1"/>
   <wangtile tileid="3" wangid="1,1,1,1,2,2,2,1"/>
   <wangtile tileid="4" wangid="1,1,2,2,2,1,2,1"/>
   <wangtile tileid="5" wangid="2,1,1,1,2,2,2,1"/>
   <wangtile tileid="6" wangid="5,5,5,5,2,5,5,5"/>
   <wangtile tileid="7" wangid="5,5,2,2,2,5,5,5"/>
   <wangtile tileid="8" wangid="5,5,2,2,2,2,2,5"/>
   <wangtile tileid="9" wangid="5,5,5,5,2,2,2,5"/>
   <wangtile tileid="10" wangid="5,5,2,2,2,5,2,5"/>
   <wangtile tileid="11" wangid="2,5,5,5,2,2,2,5"/>
   <wangtile tileid="12" wangid="4,4,4,4,2,4,4,4"/>
   <wangtile tileid="13" wangid="4,4,2,2,2,4,4,4"/>
   <wangtile tileid="14" wangid="4,4,2,2,2,2,2,4"/>
   <wangtile tileid="15" wangid="4,4,4,4,2,2,2,4"/>
   <wangtile tileid="16" wangid="4,4,2,2,2,4,2,4"/>
   <wangtile tileid="17" wangid="2,4,4,4,2,2,2,4"/>
   <wangtile tileid="36" wangid="2,1,1,1,2,1,1,1"/>
   <wangtile tileid="37" wangid="2,2,2,2,2,1,1,1"/>
   <wangtile tileid="38" wangid="2,2,2,2,2,2,2,2"/>
   <wangtile tileid="39" wangid="2,1,1,1,2,2,2,2"/>
   <wangtile tileid="40" wangid="2,2,2,1,2,1,1,1"/>
   <wangtile tileid="41" wangid="2,1,2,1,1,1,2,2"/>
   <wangtile tileid="42" wangid="2,5,5,5,2,5,5,5"/>
   <wangtile tileid="43" wangid="2,2,2,2,2,5,5,5"/>
   <wangtile tileid="44" wangid="2,2,2,2,2,2,2,2"/>
   <wangtile tileid="45" wangid="2,5,5,5,2,2,2,2"/>
   <wangtile tileid="46" wangid="2,2,2,5,2,5,5,5"/>
   <wangtile tileid="47" wangid="2,5,2,5,5,5,2,2"/>
   <wangtile tileid="48" wangid="2,4,4,4,2,4,4,4"/>
   <wangtile tileid="49" wangid="2,2,2,2,2,4,4,4"/>
   <wangtile tileid="50" wangid="2,2,2,2,2,2,2,2"/>
   <wangtile tileid="51" wangid="2,4,4,4,2,2,2,2"/>
   <wangtile tileid="52" wangid="2,2,2,4,2,4,4,4"/>
   <wangtile tileid="53" wangid="2,4,2,4,4,4,2,2"/>
   <wangtile tileid="72" wangid="2,1,1,1,1,1,1,1"/>
   <wangtile tileid="73" wangid="2,2,2,1,1,1,1,1"/>
   <wangtile tileid="74" wangid="2,2,2,1,1,1,2,2"/>
   <wangtile tileid="75" wangid="2,1,1,1,1,1,2,2"/>
   <wangtile tileid="76" wangid="2,1,2,2,2,1,1,1"/>
   <wangtile tileid="77" wangid="1,1,2,1,2,2,2,1"/>
   <wangtile tileid="78" wangid="2,5,5,5,5,5,5,5"/>
   <wangtile tileid="79" wangid="2,2,2,5,5,5,5,5"/>
   <wangtile tileid="80" wangid="2,2,2,5,5,5,2,2"/>
   <wangtile tileid="81" wangid="2,5,5,5,5,5,2,2"/>
   <wangtile tileid="82" wangid="2,5,2,2,2,5,5,5"/>
   <wangtile tileid="83" wangid="5,5,2,5,2,2,2,5"/>
   <wangtile tileid="84" wangid="2,4,4,4,4,4,4,4"/>
   <wangtile tileid="85" wangid="2,2,2,4,4,4,4,4"/>
   <wangtile tileid="86" wangid="2,2,2,4,4,4,2,2"/>
   <wangtile tileid="87" wangid="2,4,4,4,4,4,2,2"/>
   <wangtile tileid="88" wangid="2,4,2,2,2,4,4,4"/>
   <wangtile tileid="89" wangid="4,4,2,4,2,2,2,4"/>
   <wangtile tileid="109" wangid="1,1,2,1,1,1,1,1"/>
   <wangtile tileid="110" wangid="1,1,2,1,1,1,2,1"/>
   <wangtile tileid="111" wangid="1,1,1,1,1,1,2,1"/>
   <wangtile tileid="112" wangid="2,2,2,1,1,1,2,1"/>
   <wangtile tileid="113" wangid="2,1,1,1,2,1,2,2"/>
   <wangtile tileid="115" wangid="5,5,2,5,5,5,5,5"/>
   <wangtile tileid="116" wangid="5,5,2,5,5,5,2,5"/>
   <wangtile tileid="117" wangid="5,5,5,5,5,5,2,5"/>
   <wangtile tileid="118" wangid="2,2,2,5,5,5,2,5"/>
   <wangtile tileid="119" wangid="2,5,5,5,2,5,2,2"/>
   <wangtile tileid="121" wangid="4,4,2,4,4,4,4,4"/>
   <wangtile tileid="122" wangid="4,4,2,4,4,4,2,4"/>
   <wangtile tileid="123" wangid="4,4,4,4,4,4,2,4"/>
   <wangtile tileid="124" wangid="2,2,2,4,4,4,2,4"/>
   <wangtile tileid="125" wangid="2,4,4,4,2,4,2,2"/>
   <wangtile tileid="144" wangid="2,2,2,1,2,2,2,2"/>
   <wangtile tileid="145" wangid="2,2,2,2,2,1,2,2"/>
   <wangtile tileid="146" wangid="1,1,2,0,2,1,1,1"/>
   <wangtile tileid="147" wangid="1,1,1,1,2,0,2,1"/>
   <wangtile tileid="148" wangid="2,1,2,2,2,2,2,1"/>
   <wangtile tileid="149" wangid="2,1,2,1,2,2,2,2"/>
   <wangtile tileid="150" wangid="2,2,2,5,2,2,2,2"/>
   <wangtile tileid="151" wangid="2,0,2,2,2,5,2,2"/>
   <wangtile tileid="152" wangid="5,5,2,5,2,5,5,5"/>
   <wangtile tileid="153" wangid="5,5,5,5,2,5,2,5"/>
   <wangtile tileid="154" wangid="2,5,2,2,2,2,2,5"/>
   <wangtile tileid="155" wangid="2,5,2,5,2,2,2,2"/>
   <wangtile tileid="156" wangid="2,2,2,4,2,2,2,2"/>
   <wangtile tileid="157" wangid="2,2,2,2,2,4,2,2"/>
   <wangtile tileid="158" wangid="4,4,2,4,2,4,4,4"/>
   <wangtile tileid="159" wangid="4,4,4,4,2,4,2,4"/>
   <wangtile tileid="160" wangid="2,4,2,2,2,2,2,4"/>
   <wangtile tileid="161" wangid="2,4,2,4,2,2,2,2"/>
   <wangtile tileid="180" wangid="2,1,2,2,2,2,2,2"/>
   <wangtile tileid="181" wangid="2,2,2,2,2,2,2,1"/>
   <wangtile tileid="182" wangid="2,0,2,1,1,1,1,1"/>
   <wangtile tileid="183" wangid="2,1,1,1,1,1,2,0"/>
   <wangtile tileid="184" wangid="2,2,2,2,2,1,2,1"/>
   <wangtile tileid="185" wangid="2,2,2,1,2,1,2,2"/>
   <wangtile tileid="186" wangid="2,5,2,2,2,2,2,2"/>
   <wangtile tileid="187" wangid="2,2,2,0,2,2,2,5"/>
   <wangtile tileid="188" wangid="2,5,2,5,5,5,5,5"/>
   <wangtile tileid="189" wangid="2,5,5,5,5,5,2,5"/>
   <wangtile tileid="190" wangid="2,2,2,2,2,5,2,5"/>
   <wangtile tileid="191" wangid="2,2,2,5,2,5,2,2"/>
   <wangtile tileid="192" wangid="2,4,2,2,2,2,2,2"/>
   <wangtile tileid="193" wangid="2,2,2,2,2,2,2,4"/>
   <wangtile tileid="194" wangid="2,4,2,4,4,4,4,4"/>
   <wangtile tileid="195" wangid="2,4,4,4,4,4,2,4"/>
   <wangtile tileid="196" wangid="2,2,2,2,2,4,2,4"/>
   <wangtile tileid="197" wangid="2,2,2,4,2,4,2,2"/>
   <wangtile tileid="216" wangid="2,1,2,2,2,1,2,1"/>
   <wangtile tileid="217" wangid="2,1,2,1,2,2,2,1"/>
   <wangtile tileid="218" wangid="2,1,2,1,1,1,2,1"/>
   <wangtile tileid="219" wangid="2,1,2,1,2,1,1,1"/>
   <wangtile tileid="220" wangid="2,2,2,1,2,2,2,1"/>
   <wangtile tileid="221" wangid="2,1,2,2,2,1,2,2"/>
   <wangtile tileid="222" wangid="2,5,2,2,2,5,2,5"/>
   <wangtile tileid="223" wangid="2,5,2,5,2,2,2,5"/>
   <wangtile tileid="224" wangid="2,5,2,5,5,5,2,5"/>
   <wangtile tileid="225" wangid="2,5,2,5,2,5,5,5"/>
   <wangtile tileid="226" wangid="5,2,5,5,5,2,5,5"/>
   <wangtile tileid="227" wangid="5,5,5,2,5,5,5,2"/>
   <wangtile tileid="228" wangid="2,4,2,2,2,4,2,4"/>
   <wangtile tileid="229" wangid="2,4,2,4,2,2,2,4"/>
   <wangtile tileid="230" wangid="2,4,2,4,4,4,2,4"/>
   <wangtile tileid="231" wangid="2,4,2,4,2,4,4,4"/>
   <wangtile tileid="232" wangid="2,2,2,4,2,2,2,4"/>
   <wangtile tileid="233" wangid="2,4,2,2,2,4,2,2"/>
   <wangtile tileid="252" wangid="2,2,2,1,2,1,2,1"/>
   <wangtile tileid="253" wangid="2,1,2,1,2,1,2,2"/>
   <wangtile tileid="254" wangid="2,1,1,1,2,1,2,1"/>
   <wangtile tileid="255" wangid="1,1,2,1,2,1,2,1"/>
   <wangtile tileid="256" wangid="2,1,2,1,2,1,2,1"/>
   <wangtile tileid="257" wangid="1,1,1,1,1,1,1,1"/>
   <wangtile tileid="258" wangid="2,2,2,5,2,5,2,5"/>
   <wangtile tileid="259" wangid="2,5,2,5,2,5,2,2"/>
   <wangtile tileid="260" wangid="2,5,5,5,2,5,2,5"/>
   <wangtile tileid="261" wangid="5,5,2,5,2,5,2,5"/>
   <wangtile tileid="262" wangid="2,5,2,5,2,5,2,5"/>
   <wangtile tileid="263" wangid="5,5,5,5,5,5,5,5"/>
   <wangtile tileid="264" wangid="2,2,2,4,2,4,2,4"/>
   <wangtile tileid="265" wangid="2,4,2,4,2,4,2,2"/>
   <wangtile tileid="266" wangid="2,4,4,4,2,4,2,4"/>
   <wangtile tileid="267" wangid="4,4,2,4,2,4,2,4"/>
   <wangtile tileid="268" wangid="2,4,2,4,2,4,2,4"/>
   <wangtile tileid="288" wangid="2,2,2,2,2,2,2,2"/>
   <wangtile tileid="289" wangid="2,2,2,2,2,2,2,2"/>
   <wangtile tileid="290" wangid="2,2,2,2,2,2,2,2"/>
   <wangtile tileid="291" wangid="2,2,2,2,2,2,2,2"/>
   <wangtile tileid="292" wangid="2,2,2,2,2,2,2,2"/>
   <wangtile tileid="293" wangid="2,2,2,2,2,2,2,2"/>
   <wangtile tileid="324" wangid="2,2,2,2,2,2,2,2"/>
   <wangtile tileid="325" wangid="2,2,2,2,2,2,2,2"/>
   <wangtile tileid="326" wangid="2,2,2,2,2,2,2,2"/>
   <wangtile tileid="327" wangid="2,2,2,2,2,2,2,2"/>
   <wangtile tileid="328" wangid="2,2,2,2,2,2,2,2"/>
   <wangtile tileid="329" wangid="2,2,2,2,2,2,2,2"/>
   <wangtile tileid="504" wangid="1,1,1,1,3,1,1,1"/>
   <wangtile tileid="505" wangid="1,1,3,3,3,1,1,1"/>
   <wangtile tileid="506" wangid="1,1,3,3,3,3,3,1"/>
   <wangtile tileid="507" wangid="1,1,1,1,3,3,3,1"/>
   <wangtile tileid="508" wangid="1,1,3,3,3,1,3,1"/>
   <wangtile tileid="509" wangid="3,1,1,1,3,3,3,1"/>
   <wangtile tileid="510" wangid="5,5,5,5,3,5,5,5"/>
   <wangtile tileid="511" wangid="5,5,3,3,3,5,5,5"/>
   <wangtile tileid="512" wangid="5,5,3,3,3,3,3,5"/>
   <wangtile tileid="513" wangid="5,5,5,5,3,3,3,5"/>
   <wangtile tileid="514" wangid="5,5,3,3,3,5,3,5"/>
   <wangtile tileid="515" wangid="3,5,5,5,3,3,3,5"/>
   <wangtile tileid="516" wangid="2,2,2,2,3,2,2,2"/>
   <wangtile tileid="517" wangid="2,2,3,3,3,2,2,2"/>
   <wangtile tileid="518" wangid="2,2,3,3,3,3,3,2"/>
   <wangtile tileid="519" wangid="2,2,2,2,3,3,3,2"/>
   <wangtile tileid="520" wangid="2,2,3,3,3,2,3,2"/>
   <wangtile tileid="521" wangid="3,2,2,2,3,3,3,2"/>
   <wangtile tileid="522" wangid="4,4,4,4,3,4,4,4"/>
   <wangtile tileid="523" wangid="4,4,3,3,3,4,4,4"/>
   <wangtile tileid="524" wangid="4,4,3,3,3,3,3,4"/>
   <wangtile tileid="525" wangid="4,4,4,4,3,3,3,4"/>
   <wangtile tileid="526" wangid="4,4,3,3,3,4,3,4"/>
   <wangtile tileid="527" wangid="3,4,4,4,3,3,3,4"/>
   <wangtile tileid="540" wangid="3,1,1,1,3,1,1,1"/>
   <wangtile tileid="541" wangid="3,3,3,3,3,1,1,1"/>
   <wangtile tileid="542" wangid="3,3,3,3,3,3,3,3"/>
   <wangtile tileid="543" wangid="3,1,1,1,3,3,3,3"/>
   <wangtile tileid="544" wangid="3,3,3,1,3,1,3,1"/>
   <wangtile tileid="545" wangid="3,1,3,1,1,1,3,3"/>
   <wangtile tileid="546" wangid="3,5,5,5,3,5,5,5"/>
   <wangtile tileid="547" wangid="3,3,3,3,3,5,5,5"/>
   <wangtile tileid="548" wangid="3,3,3,3,3,3,3,3"/>
   <wangtile tileid="549" wangid="3,5,5,5,3,3,3,3"/>
   <wangtile tileid="550" wangid="3,3,3,5,3,5,5,5"/>
   <wangtile tileid="551" wangid="3,5,3,5,5,5,3,3"/>
   <wangtile tileid="552" wangid="3,2,2,2,3,2,2,2"/>
   <wangtile tileid="553" wangid="3,3,3,3,3,2,2,2"/>
   <wangtile tileid="554" wangid="3,3,3,3,3,3,3,3"/>
   <wangtile tileid="555" wangid="3,2,2,2,3,3,3,3"/>
   <wangtile tileid="556" wangid="3,3,3,2,3,2,2,2"/>
   <wangtile tileid="557" wangid="3,2,3,2,2,2,3,3"/>
   <wangtile tileid="558" wangid="3,4,4,4,3,4,4,4"/>
   <wangtile tileid="559" wangid="3,3,3,3,3,4,4,4"/>
   <wangtile tileid="560" wangid="3,3,3,3,3,3,3,3"/>
   <wangtile tileid="561" wangid="3,4,4,4,3,3,3,3"/>
   <wangtile tileid="562" wangid="3,3,3,4,3,4,4,4"/>
   <wangtile tileid="563" wangid="3,4,3,4,4,4,3,3"/>
   <wangtile tileid="576" wangid="3,1,1,1,1,1,1,1"/>
   <wangtile tileid="577" wangid="3,3,3,1,1,1,1,1"/>
   <wangtile tileid="578" wangid="3,3,3,1,1,1,3,3"/>
   <wangtile tileid="579" wangid="3,1,1,1,1,1,3,3"/>
   <wangtile tileid="580" wangid="3,1,3,3,3,1,1,1"/>
   <wangtile tileid="581" wangid="1,1,3,1,3,3,3,1"/>
   <wangtile tileid="582" wangid="3,5,5,5,5,5,5,5"/>
   <wangtile tileid="583" wangid="3,3,3,5,5,5,5,5"/>
   <wangtile tileid="584" wangid="3,3,3,5,5,5,3,3"/>
   <wangtile tileid="585" wangid="3,5,5,5,5,5,3,3"/>
   <wangtile tileid="586" wangid="3,5,3,3,3,5,5,5"/>
   <wangtile tileid="587" wangid="5,5,3,5,3,3,3,5"/>
   <wangtile tileid="588" wangid="3,2,2,2,2,2,2,2"/>
   <wangtile tileid="589" wangid="3,3,3,2,2,2,2,2"/>
   <wangtile tileid="590" wangid="3,3,3,2,2,2,3,3"/>
   <wangtile tileid="591" wangid="3,2,2,2,2,2,3,3"/>
   <wangtile tileid="592" wangid="3,2,3,3,3,2,2,2"/>
   <wangtile tileid="593" wangid="2,2,3,2,3,3,3,2"/>
   <wangtile tileid="594" wangid="3,4,4,4,4,4,4,4"/>
   <wangtile tileid="595" wangid="3,3,3,4,4,4,4,4"/>
   <wangtile tileid="596" wangid="3,3,3,4,4,4,3,3"/>
   <wangtile tileid="597" wangid="3,4,4,4,4,4,3,3"/>
   <wangtile tileid="598" wangid="3,4,3,3,3,4,4,4"/>
   <wangtile tileid="599" wangid="4,4,3,4,3,3,3,4"/>
   <wangtile tileid="613" wangid="1,1,3,1,1,1,1,1"/>
   <wangtile tileid="614" wangid="1,1,3,1,1,1,3,1"/>
   <wangtile tileid="615" wangid="1,1,1,1,1,1,3,1"/>
   <wangtile tileid="616" wangid="3,3,3,1,1,1,3,1"/>
   <wangtile tileid="617" wangid="3,1,1,1,3,1,3,3"/>
   <wangtile tileid="619" wangid="5,5,3,5,5,5,5,5"/>
   <wangtile tileid="620" wangid="5,5,3,5,5,5,3,5"/>
   <wangtile tileid="621" wangid="5,5,5,5,5,5,3,5"/>
   <wangtile tileid="622" wangid="3,3,3,5,5,5,3,5"/>
   <wangtile tileid="623" wangid="3,5,5,5,3,5,3,3"/>
   <wangtile tileid="625" wangid="2,2,3,2,2,2,2,2"/>
   <wangtile tileid="626" wangid="2,2,3,2,2,2,3,2"/>
   <wangtile tileid="627" wangid="2,2,2,2,2,2,3,2"/>
   <wangtile tileid="628" wangid="3,3,3,2,2,2,3,2"/>
   <wangtile tileid="629" wangid="3,2,2,2,3,2,3,3"/>
   <wangtile tileid="631" wangid="4,4,3,4,4,4,4,4"/>
   <wangtile tileid="632" wangid="4,4,3,4,4,4,3,4"/>
   <wangtile tileid="633" wangid="4,4,4,4,4,4,3,4"/>
   <wangtile tileid="634" wangid="3,3,3,4,4,4,3,4"/>
   <wangtile tileid="635" wangid="3,4,4,4,3,4,3,3"/>
   <wangtile tileid="648" wangid="3,3,3,1,3,3,3,3"/>
   <wangtile tileid="649" wangid="3,3,3,3,3,1,3,3"/>
   <wangtile tileid="650" wangid="1,1,3,1,3,1,1,1"/>
   <wangtile tileid="651" wangid="1,1,1,1,3,1,3,1"/>
   <wangtile tileid="652" wangid="3,1,3,3,3,3,3,1"/>
   <wangtile tileid="653" wangid="3,1,3,1,3,3,3,3"/>
   <wangtile tileid="654" wangid="3,3,3,5,3,3,3,3"/>
   <wangtile tileid="655" wangid="3,3,3,3,3,5,3,3"/>
   <wangtile tileid="656" wangid="5,5,3,5,3,5,5,5"/>
   <wangtile tileid="657" wangid="5,5,5,5,3,5,3,5"/>
   <wangtile tileid="658" wangid="3,5,3,3,3,3,3,5"/>
   <wangtile tileid="659" wangid="3,5,3,5,3,3,3,3"/>
   <wangtile tileid="660" wangid="3,3,3,2,3,3,3,3"/>
   <wangtile tileid="661" wangid="3,3,3,3,3,2,3,3"/>
   <wangtile tileid="662" wangid="2,2,3,2,3,2,2,2"/>
   <wangtile tileid="663" wangid="2,2,2,2,3,2,3,2"/>
   <wangtile tileid="664" wangid="3,2,3,3,3,3,3,2"/>
   <wangtile tileid="665" wangid="3,2,3,2,3,3,3,3"/>
   <wangtile tileid="666" wangid="3,3,3,4,3,3,3,3"/>
   <wangtile tileid="667" wangid="3,3,3,3,3,4,3,3"/>
   <wangtile tileid="668" wangid="4,4,3,4,3,4,4,4"/>
   <wangtile tileid="669" wangid="4,4,4,4,3,4,3,4"/>
   <wangtile tileid="670" wangid="3,4,3,3,3,3,3,4"/>
   <wangtile tileid="671" wangid="3,4,3,4,3,3,3,3"/>
   <wangtile tileid="684" wangid="3,1,3,3,3,3,3,3"/>
   <wangtile tileid="685" wangid="3,3,3,3,3,3,3,1"/>
   <wangtile tileid="686" wangid="3,1,3,1,1,1,1,1"/>
   <wangtile tileid="687" wangid="3,1,1,1,1,1,3,1"/>
   <wangtile tileid="688" wangid="3,3,3,3,3,1,3,1"/>
   <wangtile tileid="689" wangid="3,3,3,1,3,1,3,3"/>
   <wangtile tileid="690" wangid="3,5,3,3,3,3,3,3"/>
   <wangtile tileid="691" wangid="3,3,3,3,3,3,3,5"/>
   <wangtile tileid="692" wangid="3,5,3,5,5,5,5,5"/>
   <wangtile tileid="693" wangid="3,5,5,5,5,5,3,5"/>
   <wangtile tileid="694" wangid="3,3,3,3,3,5,3,5"/>
   <wangtile tileid="695" wangid="3,3,3,5,3,5,3,3"/>
   <wangtile tileid="696" wangid="3,2,3,3,3,3,3,3"/>
   <wangtile tileid="697" wangid="3,3,3,3,3,3,3,2"/>
   <wangtile tileid="698" wangid="3,2,3,2,2,2,2,2"/>
   <wangtile tileid="699" wangid="3,2,2,2,2,2,3,2"/>
   <wangtile tileid="700" wangid="3,3,3,3,3,2,3,2"/>
   <wangtile tileid="701" wangid="3,3,3,2,3,2,3,3"/>
   <wangtile tileid="702" wangid="3,4,3,3,3,3,3,3"/>
   <wangtile tileid="703" wangid="3,3,3,3,3,3,3,4"/>
   <wangtile tileid="704" wangid="3,4,3,4,4,4,4,4"/>
   <wangtile tileid="705" wangid="3,4,4,4,4,4,3,4"/>
   <wangtile tileid="706" wangid="3,3,3,3,3,4,3,4"/>
   <wangtile tileid="707" wangid="3,3,3,4,3,4,3,3"/>
   <wangtile tileid="720" wangid="3,1,3,3,3,1,3,1"/>
   <wangtile tileid="721" wangid="3,1,3,1,3,3,3,1"/>
   <wangtile tileid="722" wangid="3,1,3,1,1,1,3,1"/>
   <wangtile tileid="723" wangid="3,1,3,1,3,1,1,1"/>
   <wangtile tileid="724" wangid="3,3,3,1,3,3,3,1"/>
   <wangtile tileid="725" wangid="3,1,3,3,3,1,3,3"/>
   <wangtile tileid="726" wangid="3,5,3,3,3,5,3,5"/>
   <wangtile tileid="727" wangid="3,5,3,5,3,3,3,5"/>
   <wangtile tileid="728" wangid="3,5,3,5,5,5,3,5"/>
   <wangtile tileid="729" wangid="3,5,3,0,3,5,5,5"/>
   <wangtile tileid="730" wangid="3,3,3,5,3,3,3,5"/>
   <wangtile tileid="731" wangid="3,5,3,3,3,5,3,3"/>
   <wangtile tileid="732" wangid="3,2,3,3,3,2,3,2"/>
   <wangtile tileid="733" wangid="3,2,3,2,3,3,3,2"/>
   <wangtile tileid="734" wangid="3,2,3,2,2,2,3,2"/>
   <wangtile tileid="735" wangid="3,2,3,2,3,2,2,2"/>
   <wangtile tileid="736" wangid="3,3,3,2,3,3,3,2"/>
   <wangtile tileid="737" wangid="3,2,3,3,3,2,3,3"/>
   <wangtile tileid="738" wangid="3,4,3,3,3,4,3,4"/>
   <wangtile tileid="739" wangid="3,4,3,4,3,3,3,4"/>
   <wangtile tileid="740" wangid="3,4,3,4,4,4,3,4"/>
   <wangtile tileid="741" wangid="3,4,3,4,3,4,4,4"/>
   <wangtile tileid="742" wangid="3,3,3,4,3,3,3,4"/>
   <wangtile tileid="743" wangid="3,4,3,3,3,4,3,3"/>
   <wangtile tileid="756" wangid="3,3,3,1,3,1,3,1"/>
   <wangtile tileid="757" wangid="3,1,3,1,3,1,3,3"/>
   <wangtile tileid="758" wangid="3,1,1,1,3,1,3,1"/>
   <wangtile tileid="759" wangid="1,1,3,1,3,1,3,1"/>
   <wangtile tileid="760" wangid="3,1,3,1,3,1,3,1"/>
   <wangtile tileid="761" wangid="1,1,1,1,1,1,1,1"/>
   <wangtile tileid="762" wangid="3,3,3,5,3,5,3,5"/>
   <wangtile tileid="763" wangid="3,5,3,5,3,5,3,3"/>
   <wangtile tileid="764" wangid="3,5,5,5,3,5,3,5"/>
   <wangtile tileid="765" wangid="5,5,3,5,3,5,3,5"/>
   <wangtile tileid="766" wangid="3,5,3,5,3,5,3,5"/>
   <wangtile tileid="768" wangid="3,3,3,2,3,2,3,2"/>
   <wangtile tileid="769" wangid="3,2,3,2,3,2,3,3"/>
   <wangtile tileid="770" wangid="3,2,2,2,3,2,3,2"/>
   <wangtile tileid="771" wangid="2,2,3,2,3,2,3,2"/>
   <wangtile tileid="772" wangid="3,2,3,2,3,2,3,2"/>
   <wangtile tileid="774" wangid="3,3,3,4,3,4,3,4"/>
   <wangtile tileid="775" wangid="3,4,3,4,3,4,3,3"/>
   <wangtile tileid="776" wangid="3,4,4,4,3,4,3,4"/>
   <wangtile tileid="777" wangid="4,4,3,4,3,4,3,4"/>
   <wangtile tileid="778" wangid="3,4,3,4,3,4,3,4"/>
   <wangtile tileid="792" wangid="3,3,3,3,3,3,3,3"/>
   <wangtile tileid="793" wangid="3,3,3,3,3,3,3,3"/>
   <wangtile tileid="794" wangid="3,3,3,3,3,3,3,3"/>
   <wangtile tileid="795" wangid="3,3,3,3,3,3,3,3"/>
   <wangtile tileid="796" wangid="3,3,3,3,3,3,3,3"/>
   <wangtile tileid="797" wangid="3,3,3,3,3,3,3,3"/>
   <wangtile tileid="828" wangid="3,3,3,3,3,3,3,3"/>
   <wangtile tileid="829" wangid="3,3,3,3,3,3,3,3"/>
   <wangtile tileid="830" wangid="3,3,3,3,3,3,3,3"/>
   <wangtile tileid="831" wangid="3,3,3,3,3,3,3,3"/>
   <wangtile tileid="832" wangid="3,3,3,3,3,3,3,3"/>
   <wangtile tileid="833" wangid="3,3,3,3,3,3,3,3"/>
   <wangtile tileid="1008" wangid="1,1,1,1,4,1,1,1"/>
   <wangtile tileid="1009" wangid="1,1,4,4,4,1,1,1"/>
   <wangtile tileid="1010" wangid="1,1,4,4,4,4,4,1"/>
   <wangtile tileid="1011" wangid="1,1,1,1,4,4,4,1"/>
   <wangtile tileid="1012" wangid="1,1,4,4,4,1,4,1"/>
   <wangtile tileid="1013" wangid="4,1,1,1,4,4,4,1"/>
   <wangtile tileid="1014" wangid="5,5,5,5,4,5,5,5"/>
   <wangtile tileid="1015" wangid="5,5,4,4,4,5,5,5"/>
   <wangtile tileid="1016" wangid="5,5,4,4,4,4,4,5"/>
   <wangtile tileid="1017" wangid="5,5,5,5,4,4,4,5"/>
   <wangtile tileid="1018" wangid="5,5,4,4,4,5,4,5"/>
   <wangtile tileid="1019" wangid="4,5,5,5,4,4,4,5"/>
   <wangtile tileid="1044" wangid="4,1,1,1,4,1,1,1"/>
   <wangtile tileid="1045" wangid="4,4,4,4,4,1,1,1"/>
   <wangtile tileid="1046" wangid="4,4,4,4,4,4,4,4"/>
   <wangtile tileid="1047" wangid="4,1,1,1,4,4,4,4"/>
   <wangtile tileid="1048" wangid="4,4,4,1,4,1,1,1"/>
   <wangtile tileid="1049" wangid="4,1,4,1,1,1,4,4"/>
   <wangtile tileid="1050" wangid="4,5,5,5,4,5,5,5"/>
   <wangtile tileid="1051" wangid="4,4,4,4,4,5,5,5"/>
   <wangtile tileid="1052" wangid="4,4,4,4,4,4,4,4"/>
   <wangtile tileid="1053" wangid="4,5,5,5,4,4,4,4"/>
   <wangtile tileid="1054" wangid="4,4,4,5,4,5,5,5"/>
   <wangtile tileid="1055" wangid="4,5,4,5,5,5,4,4"/>
   <wangtile tileid="1080" wangid="4,1,1,1,1,1,1,1"/>
   <wangtile tileid="1081" wangid="4,4,4,1,1,1,1,1"/>
   <wangtile tileid="1082" wangid="4,4,4,1,1,1,4,4"/>
   <wangtile tileid="1083" wangid="4,1,1,1,1,1,4,4"/>
   <wangtile tileid="1084" wangid="4,1,4,4,4,1,1,1"/>
   <wangtile tileid="1085" wangid="1,1,4,1,4,4,4,1"/>
   <wangtile tileid="1086" wangid="4,5,5,5,5,5,5,5"/>
   <wangtile tileid="1087" wangid="4,4,4,5,5,5,5,5"/>
   <wangtile tileid="1088" wangid="4,4,4,5,5,5,4,4"/>
   <wangtile tileid="1089" wangid="4,5,5,5,5,5,4,4"/>
   <wangtile tileid="1090" wangid="4,5,4,4,4,5,5,5"/>
   <wangtile tileid="1091" wangid="5,5,4,5,4,4,4,5"/>
   <wangtile tileid="1117" wangid="1,1,4,1,1,1,1,1"/>
   <wangtile tileid="1118" wangid="1,1,4,1,1,1,4,1"/>
   <wangtile tileid="1119" wangid="1,1,1,1,1,1,4,1"/>
   <wangtile tileid="1120" wangid="4,4,4,1,1,1,4,1"/>
   <wangtile tileid="1121" wangid="4,1,1,1,4,1,4,4"/>
   <wangtile tileid="1123" wangid="5,5,4,5,5,5,5,5"/>
   <wangtile tileid="1124" wangid="5,5,4,5,5,5,4,5"/>
   <wangtile tileid="1125" wangid="5,5,5,5,5,5,4,5"/>
   <wangtile tileid="1126" wangid="4,4,4,5,5,5,4,5"/>
   <wangtile tileid="1127" wangid="4,5,5,5,4,5,4,4"/>
   <wangtile tileid="1152" wangid="4,4,4,1,4,4,4,4"/>
   <wangtile tileid="1153" wangid="4,4,4,4,4,1,4,4"/>
   <wangtile tileid="1154" wangid="1,1,4,1,4,1,1,1"/>
   <wangtile tileid="1155" wangid="1,1,1,1,4,1,4,1"/>
   <wangtile tileid="1156" wangid="4,1,4,4,4,4,4,1"/>
   <wangtile tileid="1157" wangid="4,1,4,1,4,4,4,4"/>
   <wangtile tileid="1158" wangid="4,4,4,5,4,4,4,4"/>
   <wangtile tileid="1159" wangid="4,4,4,4,4,5,4,4"/>
   <wangtile tileid="1160" wangid="5,5,4,5,4,5,5,5"/>
   <wangtile tileid="1161" wangid="5,5,5,5,4,5,4,5"/>
   <wangtile tileid="1162" wangid="4,5,4,4,4,4,4,5"/>
   <wangtile tileid="1163" wangid="4,5,4,5,4,4,4,4"/>
   <wangtile tileid="1188" wangid="4,1,4,4,4,4,4,4"/>
   <wangtile tileid="1189" wangid="4,4,4,4,4,4,4,1"/>
   <wangtile tileid="1190" wangid="4,1,4,1,1,1,1,1"/>
   <wangtile tileid="1191" wangid="4,1,1,1,1,1,4,1"/>
   <wangtile tileid="1192" wangid="4,4,4,4,4,1,4,1"/>
   <wangtile tileid="1193" wangid="4,4,4,1,4,1,4,4"/>
   <wangtile tileid="1194" wangid="4,5,4,4,4,4,4,4"/>
   <wangtile tileid="1195" wangid="4,4,4,4,4,4,4,5"/>
   <wangtile tileid="1196" wangid="4,5,4,5,5,5,5,5"/>
   <wangtile tileid="1197" wangid="4,5,5,5,5,5,4,5"/>
   <wangtile tileid="1198" wangid="4,4,4,4,4,5,4,5"/>
   <wangtile tileid="1199" wangid="4,4,4,5,4,5,4,4"/>
   <wangtile tileid="1224" wangid="4,1,4,4,4,1,4,1"/>
   <wangtile tileid="1225" wangid="4,1,4,1,4,4,4,1"/>
   <wangtile tileid="1226" wangid="4,1,4,1,1,1,4,1"/>
   <wangtile tileid="1227" wangid="4,1,4,1,4,1,1,1"/>
   <wangtile tileid="1228" wangid="4,4,4,1,4,4,4,1"/>
   <wangtile tileid="1229" wangid="4,1,4,4,4,1,4,4"/>
   <wangtile tileid="1230" wangid="4,5,4,4,4,5,4,5"/>
   <wangtile tileid="1231" wangid="4,5,4,5,4,4,4,5"/>
   <wangtile tileid="1232" wangid="4,5,4,5,5,5,4,5"/>
   <wangtile tileid="1233" wangid="4,5,4,5,4,5,5,5"/>
   <wangtile tileid="1234" wangid="4,4,4,5,4,4,4,5"/>
   <wangtile tileid="1235" wangid="4,5,4,4,4,5,4,4"/>
   <wangtile tileid="1260" wangid="4,4,4,1,4,1,4,1"/>
   <wangtile tileid="1261" wangid="4,1,4,1,4,1,4,4"/>
   <wangtile tileid="1262" wangid="4,1,1,1,4,1,4,1"/>
   <wangtile tileid="1263" wangid="1,1,4,1,4,1,4,1"/>
   <wangtile tileid="1264" wangid="4,1,4,1,4,1,4,1"/>
   <wangtile tileid="1265" wangid="1,1,1,1,1,1,1,1"/>
   <wangtile tileid="1266" wangid="4,4,4,5,4,5,4,5"/>
   <wangtile tileid="1267" wangid="4,5,4,5,4,5,4,4"/>
   <wangtile tileid="1268" wangid="4,5,5,5,4,5,4,5"/>
   <wangtile tileid="1269" wangid="5,5,4,5,4,5,4,5"/>
   <wangtile tileid="1270" wangid="4,5,4,5,4,5,4,5"/>
   <wangtile tileid="1296" wangid="4,4,4,4,4,4,4,4"/>
   <wangtile tileid="1297" wangid="4,4,4,4,4,4,4,4"/>
   <wangtile tileid="1298" wangid="4,4,4,4,4,4,4,4"/>
   <wangtile tileid="1299" wangid="4,4,4,4,4,4,4,4"/>
   <wangtile tileid="1300" wangid="4,4,4,4,4,4,4,4"/>
   <wangtile tileid="1301" wangid="4,4,4,4,4,4,4,4"/>
   <wangtile tileid="1332" wangid="4,4,4,4,4,4,4,4"/>
   <wangtile tileid="1333" wangid="4,4,4,4,4,4,4,4"/>
   <wangtile tileid="1334" wangid="4,4,4,4,4,4,4,4"/>
   <wangtile tileid="1335" wangid="4,4,4,4,4,4,4,4"/>
   <wangtile tileid="1336" wangid="4,4,4,4,4,4,4,4"/>
   <wangtile tileid="1337" wangid="4,4,4,4,4,4,4,4"/>
   <wangtile tileid="1512" wangid="1,1,1,1,0,1,1,1"/>
   <wangtile tileid="1513" wangid="1,1,0,0,0,1,1,1"/>
   <wangtile tileid="1514" wangid="1,1,0,0,0,0,0,1"/>
   <wangtile tileid="1515" wangid="1,1,1,1,0,0,0,1"/>
   <wangtile tileid="1516" wangid="1,1,0,0,0,1,0,1"/>
   <wangtile tileid="1517" wangid="0,1,1,1,0,0,0,1"/>
   <wangtile tileid="1518" wangid="5,5,5,5,0,5,5,5"/>
   <wangtile tileid="1519" wangid="5,5,0,0,0,5,5,5"/>
   <wangtile tileid="1520" wangid="5,5,0,0,0,0,0,5"/>
   <wangtile tileid="1521" wangid="5,5,5,5,0,0,0,5"/>
   <wangtile tileid="1522" wangid="5,5,0,0,0,5,0,5"/>
   <wangtile tileid="1523" wangid="0,5,5,5,0,0,0,5"/>
   <wangtile tileid="1524" wangid="2,2,2,2,0,2,2,2"/>
   <wangtile tileid="1525" wangid="2,2,0,0,0,2,2,2"/>
   <wangtile tileid="1526" wangid="2,2,0,0,0,0,0,2"/>
   <wangtile tileid="1527" wangid="2,2,2,2,0,0,0,2"/>
   <wangtile tileid="1528" wangid="2,2,0,0,0,2,0,2"/>
   <wangtile tileid="1529" wangid="0,2,2,2,0,0,0,2"/>
   <wangtile tileid="1530" wangid="3,3,3,3,0,3,3,3"/>
   <wangtile tileid="1531" wangid="3,3,0,0,0,3,3,3"/>
   <wangtile tileid="1532" wangid="3,3,0,0,0,0,0,3"/>
   <wangtile tileid="1533" wangid="3,3,3,3,0,0,0,3"/>
   <wangtile tileid="1534" wangid="3,3,0,0,0,3,0,3"/>
   <wangtile tileid="1535" wangid="0,3,3,3,0,0,0,3"/>
   <wangtile tileid="1536" wangid="4,4,4,4,0,4,4,4"/>
   <wangtile tileid="1537" wangid="4,4,0,0,0,4,4,4"/>
   <wangtile tileid="1538" wangid="4,4,0,0,0,0,0,4"/>
   <wangtile tileid="1539" wangid="4,4,4,4,0,0,0,4"/>
   <wangtile tileid="1540" wangid="4,4,0,0,0,4,0,4"/>
   <wangtile tileid="1541" wangid="0,4,4,4,0,0,0,4"/>
   <wangtile tileid="1548" wangid="0,1,1,1,0,1,1,1"/>
   <wangtile tileid="1549" wangid="0,0,0,0,0,1,1,1"/>
   <wangtile tileid="1551" wangid="0,1,1,1,0,0,0,0"/>
   <wangtile tileid="1552" wangid="0,0,0,1,0,1,1,1"/>
   <wangtile tileid="1553" wangid="0,1,0,1,1,1,0,0"/>
   <wangtile tileid="1554" wangid="0,5,5,5,0,5,5,5"/>
   <wangtile tileid="1555" wangid="0,0,0,0,0,5,5,5"/>
   <wangtile tileid="1557" wangid="0,5,5,5,0,0,0,0"/>
   <wangtile tileid="1558" wangid="0,0,0,5,0,5,5,5"/>
   <wangtile tileid="1559" wangid="0,5,0,5,5,5,0,0"/>
   <wangtile tileid="1560" wangid="0,2,2,2,0,2,2,2"/>
   <wangtile tileid="1561" wangid="0,0,0,0,0,2,2,2"/>
   <wangtile tileid="1563" wangid="0,2,2,2,0,0,0,0"/>
   <wangtile tileid="1564" wangid="0,0,0,2,0,2,2,2"/>
   <wangtile tileid="1565" wangid="0,2,0,2,2,2,0,0"/>
   <wangtile tileid="1566" wangid="0,3,3,3,0,3,3,3"/>
   <wangtile tileid="1567" wangid="0,0,0,0,0,3,3,3"/>
   <wangtile tileid="1569" wangid="0,3,3,3,0,0,0,0"/>
   <wangtile tileid="1570" wangid="0,0,0,3,0,3,3,3"/>
   <wangtile tileid="1571" wangid="0,3,0,3,3,3,0,0"/>
   <wangtile tileid="1572" wangid="0,4,4,4,0,4,4,4"/>
   <wangtile tileid="1573" wangid="0,0,0,0,0,4,4,4"/>
   <wangtile tileid="1575" wangid="0,4,4,4,0,0,0,0"/>
   <wangtile tileid="1576" wangid="0,0,0,4,0,4,4,4"/>
   <wangtile tileid="1577" wangid="0,4,0,4,4,4,0,0"/>
   <wangtile tileid="1584" wangid="0,1,1,1,1,1,1,1"/>
   <wangtile tileid="1585" wangid="0,0,0,1,1,1,1,1"/>
   <wangtile tileid="1586" wangid="0,0,0,1,1,1,0,0"/>
   <wangtile tileid="1587" wangid="0,1,1,1,1,1,0,0"/>
   <wangtile tileid="1588" wangid="0,1,0,0,0,1,1,1"/>
   <wangtile tileid="1589" wangid="1,1,0,1,0,0,0,1"/>
   <wangtile tileid="1590" wangid="0,5,5,5,5,5,5,5"/>
   <wangtile tileid="1591" wangid="0,0,0,5,5,5,5,5"/>
   <wangtile tileid="1592" wangid="0,0,0,5,5,5,0,0"/>
   <wangtile tileid="1593" wangid="0,5,5,5,5,5,0,0"/>
   <wangtile tileid="1594" wangid="0,5,0,0,0,5,5,5"/>
   <wangtile tileid="1595" wangid="5,5,0,5,0,0,0,5"/>
   <wangtile tileid="1596" wangid="0,2,2,2,2,2,2,2"/>
   <wangtile tileid="1597" wangid="0,0,0,2,2,2,2,2"/>
   <wangtile tileid="1598" wangid="0,0,0,2,2,2,0,0"/>
   <wangtile tileid="1599" wangid="0,2,2,2,2,2,0,0"/>
   <wangtile tileid="1600" wangid="0,2,0,0,0,2,2,2"/>
   <wangtile tileid="1601" wangid="2,2,0,2,0,0,0,2"/>
   <wangtile tileid="1602" wangid="0,3,3,3,3,3,3,3"/>
   <wangtile tileid="1603" wangid="0,0,0,3,3,3,3,3"/>
   <wangtile tileid="1604" wangid="0,0,0,3,3,3,0,0"/>
   <wangtile tileid="1605" wangid="0,3,3,3,3,3,0,0"/>
   <wangtile tileid="1606" wangid="0,3,0,0,0,3,3,3"/>
   <wangtile tileid="1607" wangid="3,3,0,3,0,0,0,3"/>
   <wangtile tileid="1608" wangid="0,4,4,4,4,4,4,4"/>
   <wangtile tileid="1609" wangid="0,0,0,4,4,4,4,4"/>
   <wangtile tileid="1610" wangid="0,0,0,4,4,4,0,0"/>
   <wangtile tileid="1611" wangid="0,4,4,4,4,4,0,0"/>
   <wangtile tileid="1612" wangid="0,4,0,0,0,4,4,4"/>
   <wangtile tileid="1613" wangid="4,4,0,4,0,0,0,4"/>
   <wangtile tileid="1621" wangid="1,1,0,1,1,1,1,1"/>
   <wangtile tileid="1622" wangid="1,1,0,1,1,1,0,1"/>
   <wangtile tileid="1623" wangid="1,1,1,1,1,1,0,1"/>
   <wangtile tileid="1624" wangid="0,0,0,1,1,1,0,1"/>
   <wangtile tileid="1625" wangid="0,1,1,1,0,1,0,0"/>
   <wangtile tileid="1627" wangid="5,5,0,5,5,5,5,5"/>
   <wangtile tileid="1628" wangid="5,5,0,5,5,5,0,5"/>
   <wangtile tileid="1629" wangid="5,5,5,5,5,5,0,5"/>
   <wangtile tileid="1630" wangid="0,0,0,5,5,5,0,5"/>
   <wangtile tileid="1631" wangid="0,5,5,5,0,5,0,0"/>
   <wangtile tileid="1633" wangid="2,2,0,2,2,2,2,2"/>
   <wangtile tileid="1634" wangid="2,2,0,2,2,2,0,2"/>
   <wangtile tileid="1635" wangid="2,2,2,2,2,2,0,2"/>
   <wangtile tileid="1636" wangid="0,0,0,2,2,2,0,2"/>
   <wangtile tileid="1637" wangid="0,2,2,2,0,2,0,0"/>
   <wangtile tileid="1639" wangid="3,3,0,3,3,3,3,3"/>
   <wangtile tileid="1640" wangid="3,3,0,3,3,3,0,3"/>
   <wangtile tileid="1641" wangid="3,3,3,3,3,3,0,3"/>
   <wangtile tileid="1642" wangid="0,0,0,3,3,3,0,3"/>
   <wangtile tileid="1643" wangid="0,3,3,3,0,3,0,0"/>
   <wangtile tileid="1645" wangid="4,4,0,4,4,4,4,4"/>
   <wangtile tileid="1646" wangid="4,4,0,4,4,4,0,4"/>
   <wangtile tileid="1647" wangid="4,4,4,4,4,4,0,4"/>
   <wangtile tileid="1648" wangid="0,0,0,4,4,4,0,4"/>
   <wangtile tileid="1649" wangid="0,4,4,4,0,4,0,0"/>
   <wangtile tileid="1656" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="1657" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="1658" wangid="1,1,0,1,0,1,1,1"/>
   <wangtile tileid="1659" wangid="1,1,1,1,0,1,0,1"/>
   <wangtile tileid="1660" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="1661" wangid="0,1,0,1,0,0,0,0"/>
   <wangtile tileid="1662" wangid="0,0,0,5,0,0,0,0"/>
   <wangtile tileid="1663" wangid="0,0,0,0,0,5,0,0"/>
   <wangtile tileid="1664" wangid="5,5,0,5,0,5,5,5"/>
   <wangtile tileid="1665" wangid="5,5,5,5,0,5,0,5"/>
   <wangtile tileid="1666" wangid="0,5,0,0,0,0,0,5"/>
   <wangtile tileid="1667" wangid="0,5,0,5,0,0,0,0"/>
   <wangtile tileid="1668" wangid="0,0,0,2,0,0,0,0"/>
   <wangtile tileid="1669" wangid="0,0,0,0,0,2,0,0"/>
   <wangtile tileid="1670" wangid="2,2,0,2,0,2,2,2"/>
   <wangtile tileid="1671" wangid="2,2,2,2,0,2,0,2"/>
   <wangtile tileid="1672" wangid="0,2,0,0,0,0,0,2"/>
   <wangtile tileid="1673" wangid="0,2,0,2,0,0,0,0"/>
   <wangtile tileid="1674" wangid="0,0,0,3,0,0,0,0"/>
   <wangtile tileid="1675" wangid="0,0,0,0,0,3,0,0"/>
   <wangtile tileid="1676" wangid="3,3,0,3,0,3,3,3"/>
   <wangtile tileid="1677" wangid="3,3,3,3,0,3,0,3"/>
   <wangtile tileid="1678" wangid="0,3,0,0,0,0,0,3"/>
   <wangtile tileid="1679" wangid="0,3,0,3,0,0,0,0"/>
   <wangtile tileid="1680" wangid="0,0,0,4,0,0,0,0"/>
   <wangtile tileid="1681" wangid="0,0,0,0,0,4,0,0"/>
   <wangtile tileid="1682" wangid="4,4,0,4,0,4,4,4"/>
   <wangtile tileid="1683" wangid="4,4,4,4,0,4,0,4"/>
   <wangtile tileid="1684" wangid="0,4,0,0,0,0,0,4"/>
   <wangtile tileid="1685" wangid="0,4,0,4,0,0,0,0"/>
   <wangtile tileid="1692" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="1693" wangid="0,0,0,0,0,0,0,1"/>
   <wangtile tileid="1694" wangid="0,1,0,1,1,1,1,1"/>
   <wangtile tileid="1695" wangid="0,1,1,1,1,1,0,1"/>
   <wangtile tileid="1696" wangid="0,0,0,0,0,1,0,1"/>
   <wangtile tileid="1697" wangid="0,0,0,1,0,1,0,0"/>
   <wangtile tileid="1698" wangid="0,5,0,0,0,0,0,0"/>
   <wangtile tileid="1699" wangid="0,0,0,0,0,0,0,5"/>
   <wangtile tileid="1700" wangid="0,5,0,5,5,5,5,5"/>
   <wangtile tileid="1701" wangid="0,5,5,5,5,5,0,5"/>
   <wangtile tileid="1702" wangid="0,0,0,0,0,5,0,5"/>
   <wangtile tileid="1703" wangid="0,0,0,5,0,5,0,0"/>
   <wangtile tileid="1704" wangid="0,2,0,0,0,0,0,0"/>
   <wangtile tileid="1705" wangid="0,0,0,0,0,0,0,2"/>
   <wangtile tileid="1706" wangid="0,2,0,2,2,2,2,2"/>
   <wangtile tileid="1707" wangid="0,2,2,2,2,2,0,2"/>
   <wangtile tileid="1708" wangid="0,0,0,0,0,2,0,2"/>
   <wangtile tileid="1709" wangid="0,0,0,2,0,2,0,0"/>
   <wangtile tileid="1710" wangid="0,3,0,0,0,0,0,0"/>
   <wangtile tileid="1711" wangid="0,0,0,0,0,0,0,3"/>
   <wangtile tileid="1712" wangid="0,3,0,3,3,3,3,3"/>
   <wangtile tileid="1713" wangid="0,3,3,3,3,3,0,3"/>
   <wangtile tileid="1714" wangid="0,0,0,0,0,3,0,3"/>
   <wangtile tileid="1715" wangid="0,0,0,3,0,3,0,0"/>
   <wangtile tileid="1716" wangid="0,4,0,0,0,0,0,0"/>
   <wangtile tileid="1717" wangid="0,0,0,0,0,0,0,4"/>
   <wangtile tileid="1718" wangid="0,4,0,4,4,4,4,4"/>
   <wangtile tileid="1719" wangid="0,4,4,4,4,4,0,4"/>
   <wangtile tileid="1720" wangid="0,0,0,0,0,4,0,4"/>
   <wangtile tileid="1721" wangid="0,0,0,4,0,4,0,0"/>
   <wangtile tileid="1728" wangid="0,1,0,0,0,1,0,1"/>
   <wangtile tileid="1729" wangid="0,1,0,1,0,0,0,1"/>
   <wangtile tileid="1730" wangid="0,1,0,1,1,1,0,1"/>
   <wangtile tileid="1731" wangid="0,1,0,1,0,1,1,1"/>
   <wangtile tileid="1732" wangid="0,0,0,1,0,0,0,1"/>
   <wangtile tileid="1733" wangid="0,1,0,0,0,1,0,0"/>
   <wangtile tileid="1734" wangid="0,5,0,0,0,5,0,5"/>
   <wangtile tileid="1735" wangid="0,5,0,5,0,0,0,5"/>
   <wangtile tileid="1736" wangid="0,5,0,5,5,5,0,5"/>
   <wangtile tileid="1737" wangid="0,5,0,5,0,5,5,5"/>
   <wangtile tileid="1738" wangid="0,0,0,5,0,0,0,5"/>
   <wangtile tileid="1739" wangid="0,5,0,0,0,5,0,0"/>
   <wangtile tileid="1740" wangid="0,2,0,0,0,2,0,2"/>
   <wangtile tileid="1741" wangid="0,2,0,2,0,0,0,2"/>
   <wangtile tileid="1742" wangid="0,2,0,2,2,2,0,2"/>
   <wangtile tileid="1743" wangid="0,2,0,2,0,2,2,2"/>
   <wangtile tileid="1744" wangid="0,0,0,2,0,0,0,2"/>
   <wangtile tileid="1745" wangid="0,2,0,0,0,2,0,0"/>
   <wangtile tileid="1746" wangid="0,3,0,0,0,3,0,3"/>
   <wangtile tileid="1747" wangid="0,3,0,3,0,0,0,3"/>
   <wangtile tileid="1748" wangid="0,3,0,3,3,3,0,3"/>
   <wangtile tileid="1749" wangid="0,3,0,3,0,3,3,3"/>
   <wangtile tileid="1750" wangid="0,0,0,3,0,0,0,3"/>
   <wangtile tileid="1751" wangid="0,3,0,0,0,3,0,0"/>
   <wangtile tileid="1752" wangid="0,4,0,0,0,4,0,4"/>
   <wangtile tileid="1753" wangid="0,4,0,4,0,0,0,4"/>
   <wangtile tileid="1754" wangid="0,4,0,4,4,4,0,4"/>
   <wangtile tileid="1755" wangid="0,4,0,4,0,4,4,4"/>
   <wangtile tileid="1756" wangid="0,0,0,4,0,0,0,4"/>
   <wangtile tileid="1757" wangid="0,4,0,0,0,4,0,0"/>
   <wangtile tileid="1764" wangid="0,0,0,1,0,1,0,1"/>
   <wangtile tileid="1765" wangid="0,1,0,1,0,1,0,0"/>
   <wangtile tileid="1766" wangid="0,1,1,1,0,1,0,1"/>
   <wangtile tileid="1767" wangid="1,1,0,1,0,1,0,1"/>
   <wangtile tileid="1768" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="1769" wangid="1,1,1,1,1,1,1,1"/>
   <wangtile tileid="1770" wangid="0,0,0,5,0,5,0,5"/>
   <wangtile tileid="1771" wangid="0,5,0,5,0,5,0,0"/>
   <wangtile tileid="1772" wangid="0,5,5,5,0,5,0,5"/>
   <wangtile tileid="1773" wangid="5,5,0,5,0,5,0,5"/>
   <wangtile tileid="1774" wangid="0,5,0,5,0,5,0,5"/>
   <wangtile tileid="1776" wangid="0,0,0,2,0,2,0,2"/>
   <wangtile tileid="1777" wangid="0,2,0,2,0,2,0,0"/>
   <wangtile tileid="1778" wangid="0,2,2,2,0,2,0,2"/>
   <wangtile tileid="1779" wangid="2,2,0,2,0,2,0,2"/>
   <wangtile tileid="1780" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="1782" wangid="0,0,0,3,0,3,0,3"/>
   <wangtile tileid="1783" wangid="0,3,0,3,0,3,0,0"/>
   <wangtile tileid="1784" wangid="0,3,3,3,0,3,0,3"/>
   <wangtile tileid="1785" wangid="3,3,0,3,0,3,0,3"/>
   <wangtile tileid="1786" wangid="0,3,0,3,0,3,0,3"/>
   <wangtile tileid="1788" wangid="0,0,0,4,0,4,0,4"/>
   <wangtile tileid="1789" wangid="0,4,0,4,0,4,0,0"/>
   <wangtile tileid="1790" wangid="0,4,4,4,0,4,0,4"/>
   <wangtile tileid="1791" wangid="4,4,0,4,0,4,0,4"/>
   <wangtile tileid="1792" wangid="0,4,0,4,0,4,0,4"/>
   <wangtile tileid="2016" wangid="1,1,1,1,0,1,1,1"/>
   <wangtile tileid="2017" wangid="1,1,0,0,0,1,1,1"/>
   <wangtile tileid="2018" wangid="1,1,0,0,0,0,0,1"/>
   <wangtile tileid="2019" wangid="1,1,1,1,0,0,0,1"/>
   <wangtile tileid="2020" wangid="1,1,0,0,0,1,0,1"/>
   <wangtile tileid="2021" wangid="0,1,1,1,0,0,0,1"/>
   <wangtile tileid="2022" wangid="5,5,5,5,0,5,5,5"/>
   <wangtile tileid="2023" wangid="5,5,0,0,0,5,5,5"/>
   <wangtile tileid="2024" wangid="5,5,0,0,0,0,0,5"/>
   <wangtile tileid="2025" wangid="5,5,5,5,0,0,0,5"/>
   <wangtile tileid="2026" wangid="5,5,0,0,0,5,0,5"/>
   <wangtile tileid="2027" wangid="0,5,5,5,0,0,0,5"/>
   <wangtile tileid="2028" wangid="2,2,2,2,0,2,2,2"/>
   <wangtile tileid="2029" wangid="2,2,0,0,0,2,2,2"/>
   <wangtile tileid="2030" wangid="2,2,0,0,0,0,0,2"/>
   <wangtile tileid="2031" wangid="2,2,2,2,0,0,0,2"/>
   <wangtile tileid="2032" wangid="2,2,0,0,0,2,0,2"/>
   <wangtile tileid="2033" wangid="0,2,2,2,0,0,0,2"/>
   <wangtile tileid="2034" wangid="3,3,3,3,0,3,3,3"/>
   <wangtile tileid="2035" wangid="3,3,0,0,0,3,3,3"/>
   <wangtile tileid="2036" wangid="3,3,0,0,0,0,0,3"/>
   <wangtile tileid="2037" wangid="3,3,3,3,0,0,0,3"/>
   <wangtile tileid="2038" wangid="3,3,0,0,0,3,0,3"/>
   <wangtile tileid="2039" wangid="0,3,3,3,0,0,0,3"/>
   <wangtile tileid="2040" wangid="4,4,4,4,0,4,4,4"/>
   <wangtile tileid="2041" wangid="4,4,0,0,0,4,4,4"/>
   <wangtile tileid="2042" wangid="4,4,0,0,0,0,0,4"/>
   <wangtile tileid="2043" wangid="4,4,4,4,0,0,0,4"/>
   <wangtile tileid="2044" wangid="4,4,0,0,0,4,0,4"/>
   <wangtile tileid="2045" wangid="0,4,4,4,0,0,0,4"/>
   <wangtile tileid="2052" wangid="0,1,1,1,0,1,1,1"/>
   <wangtile tileid="2053" wangid="0,0,0,0,0,1,1,1"/>
   <wangtile tileid="2055" wangid="0,1,1,1,0,0,0,0"/>
   <wangtile tileid="2056" wangid="0,0,0,1,0,1,1,1"/>
   <wangtile tileid="2057" wangid="0,1,0,1,1,1,0,0"/>
   <wangtile tileid="2058" wangid="0,5,5,5,0,5,5,5"/>
   <wangtile tileid="2059" wangid="0,0,0,0,0,5,5,5"/>
   <wangtile tileid="2061" wangid="0,5,5,5,0,0,0,0"/>
   <wangtile tileid="2062" wangid="0,0,0,5,0,5,5,5"/>
   <wangtile tileid="2063" wangid="0,5,0,5,5,5,0,0"/>
   <wangtile tileid="2064" wangid="0,2,2,2,0,2,2,2"/>
   <wangtile tileid="2065" wangid="0,0,0,0,0,2,2,2"/>
   <wangtile tileid="2067" wangid="0,2,2,2,0,0,0,0"/>
   <wangtile tileid="2068" wangid="0,0,0,2,0,2,2,2"/>
   <wangtile tileid="2069" wangid="0,2,0,2,2,2,0,0"/>
   <wangtile tileid="2070" wangid="0,3,3,3,0,3,3,3"/>
   <wangtile tileid="2071" wangid="0,0,0,0,0,3,3,3"/>
   <wangtile tileid="2073" wangid="0,3,3,3,0,0,0,0"/>
   <wangtile tileid="2074" wangid="0,0,0,3,0,3,3,3"/>
   <wangtile tileid="2075" wangid="0,3,0,3,3,3,0,0"/>
   <wangtile tileid="2076" wangid="0,4,4,4,0,4,4,4"/>
   <wangtile tileid="2077" wangid="0,0,0,0,0,4,4,4"/>
   <wangtile tileid="2079" wangid="0,4,4,4,0,0,0,0"/>
   <wangtile tileid="2080" wangid="0,0,0,4,0,4,4,4"/>
   <wangtile tileid="2081" wangid="0,4,0,4,4,4,0,0"/>
   <wangtile tileid="2088" wangid="0,1,1,1,1,1,1,1"/>
   <wangtile tileid="2089" wangid="0,0,0,1,1,1,1,1"/>
   <wangtile tileid="2090" wangid="0,0,0,1,1,1,0,0"/>
   <wangtile tileid="2091" wangid="0,1,1,1,1,1,0,0"/>
   <wangtile tileid="2092" wangid="0,1,0,0,0,1,1,1"/>
   <wangtile tileid="2093" wangid="1,1,0,1,0,0,0,1"/>
   <wangtile tileid="2094" wangid="0,5,5,5,5,5,5,5"/>
   <wangtile tileid="2095" wangid="0,0,0,5,5,5,5,5"/>
   <wangtile tileid="2096" wangid="0,0,0,5,5,5,0,0"/>
   <wangtile tileid="2097" wangid="0,5,5,5,5,5,0,0"/>
   <wangtile tileid="2098" wangid="0,5,0,0,0,5,5,5"/>
   <wangtile tileid="2099" wangid="5,5,0,5,0,0,0,5"/>
   <wangtile tileid="2100" wangid="0,2,2,2,2,2,2,2"/>
   <wangtile tileid="2101" wangid="0,0,0,2,2,2,2,2"/>
   <wangtile tileid="2102" wangid="0,0,0,2,2,2,0,0"/>
   <wangtile tileid="2103" wangid="0,2,2,2,2,2,0,0"/>
   <wangtile tileid="2104" wangid="0,2,0,0,0,2,2,2"/>
   <wangtile tileid="2105" wangid="2,2,0,2,0,0,0,2"/>
   <wangtile tileid="2106" wangid="0,3,3,3,3,3,3,3"/>
   <wangtile tileid="2107" wangid="0,0,0,3,3,3,3,3"/>
   <wangtile tileid="2108" wangid="0,0,0,3,3,3,0,0"/>
   <wangtile tileid="2109" wangid="0,3,3,3,3,3,0,0"/>
   <wangtile tileid="2110" wangid="0,3,0,0,0,3,3,3"/>
   <wangtile tileid="2111" wangid="3,3,0,3,0,0,0,3"/>
   <wangtile tileid="2112" wangid="0,4,4,4,4,4,4,4"/>
   <wangtile tileid="2113" wangid="0,0,0,4,4,4,4,4"/>
   <wangtile tileid="2114" wangid="0,0,0,4,4,4,0,0"/>
   <wangtile tileid="2115" wangid="0,4,4,4,4,4,0,0"/>
   <wangtile tileid="2116" wangid="0,4,0,0,0,4,4,4"/>
   <wangtile tileid="2117" wangid="4,4,0,4,0,0,0,4"/>
   <wangtile tileid="2125" wangid="1,1,0,1,1,1,1,1"/>
   <wangtile tileid="2126" wangid="1,1,0,1,1,1,0,1"/>
   <wangtile tileid="2127" wangid="1,1,1,1,1,1,0,1"/>
   <wangtile tileid="2128" wangid="0,0,0,1,1,1,0,1"/>
   <wangtile tileid="2129" wangid="0,1,1,1,0,1,0,0"/>
   <wangtile tileid="2131" wangid="5,5,0,5,5,5,5,5"/>
   <wangtile tileid="2132" wangid="5,5,0,5,5,5,0,5"/>
   <wangtile tileid="2133" wangid="5,5,5,5,5,5,0,5"/>
   <wangtile tileid="2134" wangid="0,0,0,5,5,5,0,5"/>
   <wangtile tileid="2135" wangid="0,5,5,5,0,5,0,0"/>
   <wangtile tileid="2137" wangid="2,2,0,2,2,2,2,2"/>
   <wangtile tileid="2138" wangid="2,2,0,2,2,2,0,2"/>
   <wangtile tileid="2139" wangid="2,2,2,2,2,2,0,2"/>
   <wangtile tileid="2140" wangid="0,0,0,2,2,2,0,2"/>
   <wangtile tileid="2141" wangid="0,2,2,2,0,2,0,0"/>
   <wangtile tileid="2143" wangid="3,3,0,3,3,3,3,3"/>
   <wangtile tileid="2144" wangid="3,3,0,3,3,3,0,3"/>
   <wangtile tileid="2145" wangid="3,3,3,3,3,3,0,3"/>
   <wangtile tileid="2146" wangid="0,0,0,3,3,3,0,3"/>
   <wangtile tileid="2147" wangid="0,3,3,3,0,3,0,0"/>
   <wangtile tileid="2149" wangid="4,4,0,4,4,4,4,4"/>
   <wangtile tileid="2150" wangid="4,4,0,4,4,4,0,4"/>
   <wangtile tileid="2151" wangid="4,4,4,4,4,4,0,4"/>
   <wangtile tileid="2152" wangid="0,0,0,4,4,4,0,4"/>
   <wangtile tileid="2153" wangid="0,4,4,4,0,4,0,0"/>
   <wangtile tileid="2160" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="2161" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="2162" wangid="1,1,0,1,0,1,1,1"/>
   <wangtile tileid="2163" wangid="1,1,1,1,0,1,0,1"/>
   <wangtile tileid="2164" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="2165" wangid="0,1,0,1,0,0,0,0"/>
   <wangtile tileid="2166" wangid="0,0,0,5,0,0,0,0"/>
   <wangtile tileid="2167" wangid="0,0,0,0,0,5,0,0"/>
   <wangtile tileid="2168" wangid="5,5,0,5,0,5,5,5"/>
   <wangtile tileid="2169" wangid="5,5,5,5,0,5,0,5"/>
   <wangtile tileid="2170" wangid="0,5,0,0,0,0,0,5"/>
   <wangtile tileid="2171" wangid="0,5,0,5,0,0,0,0"/>
   <wangtile tileid="2172" wangid="0,0,0,2,0,0,0,0"/>
   <wangtile tileid="2173" wangid="0,0,0,0,0,2,0,0"/>
   <wangtile tileid="2174" wangid="2,2,0,2,0,2,2,2"/>
   <wangtile tileid="2175" wangid="2,2,2,2,0,2,0,2"/>
   <wangtile tileid="2176" wangid="0,2,0,0,0,0,0,2"/>
   <wangtile tileid="2177" wangid="0,2,0,2,0,0,0,0"/>
   <wangtile tileid="2178" wangid="0,0,0,3,0,0,0,0"/>
   <wangtile tileid="2179" wangid="0,0,0,0,0,3,0,0"/>
   <wangtile tileid="2180" wangid="3,3,0,3,0,3,3,3"/>
   <wangtile tileid="2181" wangid="3,3,3,3,0,3,0,3"/>
   <wangtile tileid="2182" wangid="0,3,0,0,0,0,0,3"/>
   <wangtile tileid="2183" wangid="0,3,0,3,0,0,0,0"/>
   <wangtile tileid="2184" wangid="0,0,0,4,0,0,0,0"/>
   <wangtile tileid="2185" wangid="0,0,0,0,0,4,0,0"/>
   <wangtile tileid="2186" wangid="4,4,0,4,0,4,4,4"/>
   <wangtile tileid="2187" wangid="4,4,4,4,0,4,0,4"/>
   <wangtile tileid="2188" wangid="0,4,0,0,0,0,0,4"/>
   <wangtile tileid="2189" wangid="0,4,0,4,0,0,0,0"/>
   <wangtile tileid="2196" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="2197" wangid="0,0,0,0,0,0,0,1"/>
   <wangtile tileid="2198" wangid="0,1,0,1,1,1,1,1"/>
   <wangtile tileid="2199" wangid="0,1,1,1,1,1,0,1"/>
   <wangtile tileid="2200" wangid="0,0,0,0,0,1,0,1"/>
   <wangtile tileid="2201" wangid="0,0,0,1,0,1,0,0"/>
   <wangtile tileid="2202" wangid="0,5,0,0,0,0,0,0"/>
   <wangtile tileid="2203" wangid="0,0,0,0,0,0,0,5"/>
   <wangtile tileid="2204" wangid="0,5,0,5,5,5,5,5"/>
   <wangtile tileid="2205" wangid="0,5,5,5,5,5,0,5"/>
   <wangtile tileid="2206" wangid="0,0,0,0,0,5,0,5"/>
   <wangtile tileid="2207" wangid="0,0,0,5,0,5,0,0"/>
   <wangtile tileid="2208" wangid="0,2,0,0,0,0,0,0"/>
   <wangtile tileid="2209" wangid="0,0,0,0,0,0,0,2"/>
   <wangtile tileid="2210" wangid="0,2,0,2,2,2,2,2"/>
   <wangtile tileid="2211" wangid="0,2,2,2,2,2,0,2"/>
   <wangtile tileid="2212" wangid="0,0,0,0,0,2,0,2"/>
   <wangtile tileid="2213" wangid="0,0,0,2,0,2,0,0"/>
   <wangtile tileid="2214" wangid="0,3,0,0,0,0,0,0"/>
   <wangtile tileid="2215" wangid="0,0,0,0,0,0,0,3"/>
   <wangtile tileid="2216" wangid="0,3,0,3,3,3,3,3"/>
   <wangtile tileid="2217" wangid="0,3,3,3,3,3,0,3"/>
   <wangtile tileid="2218" wangid="0,0,0,0,0,3,0,3"/>
   <wangtile tileid="2219" wangid="0,0,0,3,0,3,0,0"/>
   <wangtile tileid="2220" wangid="0,4,0,0,0,0,0,0"/>
   <wangtile tileid="2221" wangid="0,0,0,0,0,0,0,4"/>
   <wangtile tileid="2222" wangid="0,4,0,4,4,4,4,4"/>
   <wangtile tileid="2223" wangid="0,4,4,4,4,4,0,4"/>
   <wangtile tileid="2224" wangid="0,0,0,0,0,4,0,4"/>
   <wangtile tileid="2225" wangid="0,0,0,4,0,4,0,0"/>
   <wangtile tileid="2232" wangid="0,1,0,0,0,1,0,1"/>
   <wangtile tileid="2233" wangid="0,1,0,1,0,0,0,1"/>
   <wangtile tileid="2234" wangid="0,1,0,1,1,1,0,1"/>
   <wangtile tileid="2235" wangid="0,1,0,1,0,1,1,1"/>
   <wangtile tileid="2236" wangid="0,0,0,1,0,0,0,1"/>
   <wangtile tileid="2237" wangid="0,1,0,0,0,1,0,0"/>
   <wangtile tileid="2238" wangid="0,5,0,0,0,5,0,5"/>
   <wangtile tileid="2239" wangid="0,5,0,5,0,0,0,5"/>
   <wangtile tileid="2240" wangid="0,5,0,5,5,5,0,5"/>
   <wangtile tileid="2241" wangid="0,5,0,5,0,5,5,5"/>
   <wangtile tileid="2242" wangid="0,0,0,5,0,0,0,5"/>
   <wangtile tileid="2243" wangid="0,5,0,0,0,5,0,0"/>
   <wangtile tileid="2244" wangid="0,2,0,0,0,2,0,2"/>
   <wangtile tileid="2245" wangid="0,2,0,2,0,0,0,2"/>
   <wangtile tileid="2246" wangid="0,2,0,2,2,2,0,2"/>
   <wangtile tileid="2247" wangid="0,2,0,2,0,2,2,2"/>
   <wangtile tileid="2248" wangid="0,0,0,2,0,0,0,2"/>
   <wangtile tileid="2249" wangid="0,2,0,0,0,2,0,0"/>
   <wangtile tileid="2250" wangid="0,3,0,0,0,3,0,3"/>
   <wangtile tileid="2251" wangid="0,3,0,3,0,0,0,3"/>
   <wangtile tileid="2252" wangid="0,3,0,3,3,3,0,3"/>
   <wangtile tileid="2253" wangid="0,3,0,3,0,3,3,3"/>
   <wangtile tileid="2254" wangid="0,0,0,3,0,0,0,3"/>
   <wangtile tileid="2255" wangid="0,3,0,0,0,3,0,0"/>
   <wangtile tileid="2256" wangid="0,4,0,0,0,4,0,4"/>
   <wangtile tileid="2257" wangid="0,4,0,4,0,0,0,4"/>
   <wangtile tileid="2258" wangid="0,4,0,4,4,4,0,4"/>
   <wangtile tileid="2259" wangid="0,4,0,4,0,4,4,4"/>
   <wangtile tileid="2260" wangid="0,0,0,4,0,0,0,4"/>
   <wangtile tileid="2261" wangid="0,4,0,0,0,4,0,0"/>
   <wangtile tileid="2268" wangid="0,0,0,1,0,1,0,1"/>
   <wangtile tileid="2269" wangid="0,1,0,1,0,1,0,0"/>
   <wangtile tileid="2270" wangid="0,1,1,1,0,1,0,1"/>
   <wangtile tileid="2271" wangid="1,1,0,1,0,1,0,1"/>
   <wangtile tileid="2272" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="2273" wangid="1,1,1,1,1,1,1,1"/>
   <wangtile tileid="2274" wangid="0,0,0,5,0,5,0,5"/>
   <wangtile tileid="2275" wangid="0,5,0,5,0,5,0,0"/>
   <wangtile tileid="2276" wangid="0,5,5,5,0,5,0,5"/>
   <wangtile tileid="2277" wangid="5,5,0,5,0,5,0,5"/>
   <wangtile tileid="2278" wangid="0,5,0,5,0,5,0,5"/>
   <wangtile tileid="2280" wangid="0,0,0,2,0,2,0,2"/>
   <wangtile tileid="2281" wangid="0,2,0,2,0,2,0,0"/>
   <wangtile tileid="2282" wangid="0,2,2,2,0,2,0,2"/>
   <wangtile tileid="2283" wangid="2,2,0,2,0,2,0,2"/>
   <wangtile tileid="2284" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="2286" wangid="0,0,0,3,0,3,0,3"/>
   <wangtile tileid="2287" wangid="0,3,0,3,0,3,0,0"/>
   <wangtile tileid="2288" wangid="0,3,3,3,0,3,0,3"/>
   <wangtile tileid="2289" wangid="3,3,0,3,0,3,0,3"/>
   <wangtile tileid="2290" wangid="0,3,0,3,0,3,0,3"/>
   <wangtile tileid="2292" wangid="0,0,0,4,0,4,0,4"/>
   <wangtile tileid="2293" wangid="0,4,0,4,0,4,0,0"/>
   <wangtile tileid="2294" wangid="0,4,4,4,0,4,0,4"/>
   <wangtile tileid="2295" wangid="4,4,0,4,0,4,0,4"/>
   <wangtile tileid="2296" wangid="0,4,0,4,0,4,0,4"/>
  </wangset>
 </wangsets>
</tileset>
